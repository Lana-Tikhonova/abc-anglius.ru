#SKD101|data_base|36|2016.01.28 17:31:17|196|2|2|1|9|2|59|11|2|1|3|1|14|1|1|30|4|18|4|6|6|5|3|1|1|1|4|2|2

DROP TABLE IF EXISTS `contests`;
CREATE TABLE `contests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` int(10) unsigned NOT NULL,
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` smallint(5) unsigned NOT NULL DEFAULT '1',
  `teacher` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `shortdesc` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `datesof` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `summarizing` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category` (`category`),
  KEY `rank` (`rank`),
  KEY `display` (`display`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `contests` VALUES
(1, 0, 100, 1, 1, 1, 'краткое описание', 'постоянно', 'ежедневно', 'пробный конкурс', '<p>полное описание</p>', 'probnyi-konkurs', 'пробный конкурс', 'описание, полное, конкурс, пробный', 'полное описание пробный конкурс', '01.jpg'),
(2, 0, 100, 1, 0, 1, '\r\nОбщие правила олимпиад по английскому языку:\r\n  •  Участники выполняют задания самостоятельно. Работы отправляют\r\nнаставники участников по электронной почте, заявка отправляется через сайт.\r\n  •  Участники, набравшие наибольшее количество баллов становя', 'постоянно', 'ежедневно', 'Английский мой любимый предмет', '', 'angliiskii-moi-lyubimyi-predmet', 'Английский мой любимый предмет', 'предмет, любимый, мой, английский', 'Английский мой любимый предмет', 'kak-budet-moskovskaya-oblast-po-anglijski-2.jpg');

DROP TABLE IF EXISTS `contests_data`;
CREATE TABLE `contests_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contest` int(10) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `fio` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `fio2` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `address` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `workplace` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `comment` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `file` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` tinyint(1) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `email` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `comment` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `files` varchar(1000) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `gallery`;
CREATE TABLE `gallery` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` int(10) unsigned NOT NULL,
  `template` tinyint(1) unsigned NOT NULL,
  `rank` tinyint(1) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `images` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `gallery` VALUES
(1, 1, 2, 1, 'Природа', 'priroda', 'Природа', '', 'Природа', 'jellyfish.jpg', 'a:5:{i:3;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:13:\"jellyfish.jpg\";s:4:\"name\";s:9:\"Jellyfish\";s:7:\"display\";s:1:\"1\";}i:4;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:14:\"hydrangeas.jpg\";s:4:\"name\";s:10:\"Hydrangeas\";s:7:\"display\";s:1:\"1\";}i:5;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:9:\"koala.jpg\";s:4:\"name\";s:5:\"Koala\";s:7:\"display\";s:1:\"1\";}i:6;a:3:{s:4:\"name\";s:13:\"Chrysanthemum\";s:7:\"display\";s:1:\"1\";s:4:\"file\";s:17:\"chrysanthemum.jpg\";}i:7;a:3:{s:4:\"name\";s:6:\"Desert\";s:7:\"display\";s:1:\"1\";s:4:\"file\";s:10:\"desert.jpg\";}}'),
(2, 1, 1, 1, 'Вторая', 'vtoraya', 'Вторая', 'вторая', 'Вторая', 'lighthouse.jpg', 'a:4:{i:1;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:17:\"chrysanthemum.jpg\";s:4:\"name\";s:13:\"Chrysanthemum\";s:7:\"display\";s:1:\"1\";}i:2;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:10:\"desert.jpg\";s:4:\"name\";s:6:\"Desert\";s:7:\"display\";s:1:\"1\";}i:3;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:10:\"tulips.jpg\";s:4:\"name\";s:6:\"Tulips\";s:7:\"display\";s:1:\"1\";}i:4;a:3:{s:4:\"name\";s:10:\"Hydrangeas\";s:7:\"display\";s:1:\"1\";s:4:\"file\";s:14:\"hydrangeas.jpg\";}}');

DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ИД',
  `rank` smallint(5) unsigned NOT NULL COMMENT 'Рейтинг',
  `display` tinyint(1) unsigned NOT NULL COMMENT 'Показывать',
  `style` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `email` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'название',
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'урл',
  `localization` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'словарь',
  `dictionary` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */ COMMENT='Языки';

INSERT INTO `languages` VALUES
(1, 100, 1, 'default', 'ottofonf@rambler.ru', 'Русский', 'rus', 'ru', 'a:107:{s:9:\"site_name\";s:31:\"Интернет магазин\";s:8:\"txt_meta\";s:17:\"<script></script>\";s:8:\"txt_head\";s:100:\"Добро пожаловать!\r\n<br>Это демо-версия интернет-магазина\";s:9:\"txt_index\";s:226:\"Тут можно разместить любой текст\r\n<br/>\r\n<br/>для входа в админпанель перейдите  <a href=\"/admin.php\">по ссылке</a>\r\n<br/>логин test\r\n<br/>пароль test\";s:10:\"txt_footer\";s:758:\"<div style=\"float:right\">\r\n<!--LiveInternet counter--><script type=\"text/javascript\"><!--\r\ndocument.write(\"<a href=\'http://www.liveinternet.ru/click\' \"+\r\n\"target=_blank><img src=\'//counter.yadro.ru/hit?t15.6;r\"+\r\nescape(document.referrer)+((typeof(screen)==\"undefined\")?\"\":\r\n\";s\"+screen.width+\"*\"+screen.height+\"*\"+(screen.colorDepth?\r\nscreen.colorDepth:screen.pixelDepth))+\";u\"+escape(document.URL)+\r\n\";h\"+escape(document.title.substring(0,80))+\";\"+Math.random()+\r\n\"\' alt=\'\' title=\'LiveInternet: показано число просмотров за 24\"+\r\n\" часа, посетителей за 24 часа и за сегодня\' \"+\r\n\"border=\'0\' width=\'88\' height=\'31\'><\\/a>\")\r\n//--></script><!--/LiveInternet-->\r\n</div>\r\ncopiright &copy; abc-cms.com 2013\";s:16:\"str_no_page_name\";s:36:\"страница не найдена\";s:16:\"txt_no_page_text\";s:63:\"запрашиваемая страница не найдена\";s:8:\"wrd_more\";s:18:\"подробнее\";s:14:\"msg_no_results\";s:64:\"по данному запросу нет результатов\";s:12:\"wrd_no_photo\";s:15:\"нет фото\";s:16:\"breadcrumb_index\";s:14:\"Главная\";s:20:\"breadcrumb_separator\";s:3:\" - \";s:14:\"make_selection\";s:27:\"сделайте выбор\";s:13:\"feedback_name\";s:15:\"Ваше имя\";s:14:\"feedback_email\";s:5:\"Email\";s:13:\"feedback_text\";s:18:\"Сообщение\";s:13:\"feedback_send\";s:18:\"Отправить\";s:15:\"feedback_attach\";s:29:\"Прикрепить файл\";s:24:\"feedback_message_is_sent\";s:55:\"сообщение успешно отправлено!\";s:22:\"msg_no_required_fields\";s:65:\"Не все обязательные поля заполнены!\";s:15:\"msg_short_login\";s:43:\"Логин слишком короткий!\";s:19:\"msg_not_valid_login\";s:37:\"Не корректный логин!\";s:19:\"msg_not_valid_email\";s:32:\"Не корректный email!\";s:22:\"msg_not_valid_password\";s:66:\"Минимальная длина пароля 5 символов!\";s:21:\"msg_not_valid_captcha\";s:51:\"Неверный код подтверждения!\";s:22:\"msg_not_valid_captcha2\";s:75:\"Для отправки сообщения включите скрипты!\";s:15:\"msg_error_email\";s:175:\"Произошла ошибка с отправлением письма, если это повторится, сообщите администартору ottofonf@gmail.ru\";s:12:\"msg_no_email\";s:92:\"Данный E-mail не закреплён ни за одним пользователем!\";s:19:\"msg_duplicate_login\";s:50:\"Такой логин уже есть в базе!\";s:19:\"msg_duplicate_email\";s:45:\"Такой email уже есть в базе!\";s:23:\"msg_not_match_passwords\";s:37:\"Пароли не совпадают!\";s:13:\"profile_hello\";s:24:\"Здравствуйте\";s:12:\"profile_link\";s:27:\"личный кабинет\";s:17:\"profile_user_edit\";s:25:\"Личные данные\";s:12:\"profile_exit\";s:10:\"выйти\";s:13:\"profile_email\";s:6:\"Еmail\";s:16:\"profile_password\";s:12:\"Пароль\";s:17:\"profile_password2\";s:35:\"Подтвердите пароль\";s:20:\"profile_new_password\";s:23:\"Новый пароль\";s:12:\"profile_save\";s:18:\"Сохранить\";s:20:\"profile_registration\";s:22:\"Регистрация\";s:13:\"profile_enter\";s:10:\"Войти\";s:19:\"profile_remember_me\";s:27:\"запомнить меня\";s:12:\"profile_auth\";s:22:\"Авторизация\";s:14:\"profile_remind\";s:26:\"забыли пароль?\";s:31:\"profile_successful_registration\";s:51:\"Регистрация прошла успешно!\";s:23:\"profile_successful_auth\";s:33:\"Вы авторизированы\";s:18:\"profile_error_auth\";s:51:\"Логин и пароль не совпадают!\";s:16:\"profile_msg_exit\";s:15:\"Вы вышли\";s:21:\"profile_go_to_profile\";s:32:\"перейти в профиль\";s:21:\"profile_remind_button\";s:31:\"Отправить письмо\";s:25:\"profile_successful_remind\";s:111:\"На указанный email отправлено письмо по восстановлению пароля!\";s:12:\"shop_catalog\";s:14:\"Каталог\";s:8:\"shop_new\";s:14:\"Новинки\";s:10:\"shop_brand\";s:26:\"Производитель\";s:12:\"shop_article\";s:14:\"Артикул\";s:15:\"shop_parameters\";s:18:\"Параметры\";s:19:\"shop_product_random\";s:29:\"Случайный товар\";s:13:\"shop_currency\";s:7:\"руб.\";s:18:\"shop_filter_button\";s:10:\"Найти\";s:7:\"reviews\";s:12:\"Отзывы\";s:10:\"review_add\";s:27:\"Оставить отзыв\";s:11:\"review_name\";s:6:\"Имя\";s:12:\"review_email\";s:5:\"Email\";s:11:\"review_text\";s:10:\"Отзыв\";s:11:\"review_send\";s:18:\"Отправить\";s:14:\"review_is_sent\";s:35:\"Ваш отзыв добавлен!\";s:10:\"basket_buy\";s:12:\"Купить\";s:6:\"basket\";s:14:\"корзина\";s:12:\"basket_empty\";s:39:\"в корзине нет товаров\";s:16:\"basket_go_basket\";s:32:\"перейти в корзину\";s:14:\"basket_go_next\";s:35:\"продолжить покупки\";s:20:\"basket_product_added\";s:46:\"товар добавлен в корзину!\";s:17:\"basket_product_id\";s:2:\"ID\";s:19:\"basket_product_name\";s:29:\"Название товара\";s:20:\"basket_product_price\";s:8:\"цена\";s:20:\"basket_product_count\";s:20:\"Количество\";s:19:\"basket_product_summ\";s:10:\"Сумма\";s:19:\"basket_product_cost\";s:18:\"Стоимость\";s:21:\"basket_product_delete\";s:14:\"удалить\";s:12:\"basket_total\";s:10:\"Итого\";s:14:\"basket_profile\";s:25:\"Личные данные\";s:15:\"basket_delivery\";s:16:\"Доставка\";s:20:\"basket_delivery_cost\";s:35:\"Стоимость доставки\";s:14:\"basket_comment\";s:22:\"Комментарий\";s:12:\"basket_order\";s:27:\"Оформить заказ\";s:13:\"basket_orders\";s:35:\"Статистика заказов\";s:17:\"basket_order_name\";s:10:\"Заказ\";s:17:\"basket_order_from\";s:4:\"от\";s:19:\"basket_order_status\";s:12:\"статус\";s:17:\"basket_order_date\";s:8:\"дата\";s:17:\"basket_view_order\";s:47:\"посмотреть заказ на сайте\";s:11:\"market_name\";s:14:\"Магазин\";s:14:\"market_company\";s:46:\"Интернет магазин товаров\";s:15:\"market_currency\";s:3:\"RUR\";s:10:\"letter_top\";s:37:\"Текст в шапке письма\";s:13:\"letter_footer\";s:41:\"Текст в подвале письма\";s:13:\"subscribe_top\";s:41:\"Текст в шапке рассылки\";s:16:\"subscribe_bottom\";s:45:\"Текст в подвале рассылки\";s:28:\"subscribe_letter_failure_str\";s:90:\"Если вы хотите отписаться от рассылки нажмите на \";s:29:\"subscribe_letter_failure_link\";s:12:\"ссылку\";s:19:\"subscribe_on_button\";s:22:\"Подписаться\";s:20:\"subscribe_on_success\";s:38:\"Вы успешно подписаны\";s:24:\"subscribe_on_letter_name\";s:52:\"Подписан новый пользователь\";s:22:\"subscribe_failure_text\";s:64:\"Подтвердите, что хотите отписаться\";s:24:\"subscribe_failure_button\";s:20:\"Отписаться\";s:25:\"subscribe_failure_success\";s:21:\"Вы отписаны\";}');

DROP TABLE IF EXISTS `letter_templates`;
CREATE TABLE `letter_templates` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `template` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `sender` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `receiver` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `letter_templates` VALUES
(1, '', 'feedback', 'Обратная связь', '', ''),
(2, '', 'basket', 'Заявка', '', ''),
(3, '', 'remind', 'Восстановление пароля', '', ''),
(4, '', 'registration', 'Регистрация', '', ''),
(5, '', 'shop_review', 'Уведомление о добавлении отзыва', '', ''),
(6, '', 'subscribe_failure', 'Отписка пользователя', '', ''),
(7, '', 'subscribe_on', 'Подписан новый пользователь', '', ''),
(8, '', 'receipt_uploaded', 'Загружена квитанция', '', ''),
(9, '', 'paid', 'Завка оплачена', '', '');

DROP TABLE IF EXISTS `letters`;
CREATE TABLE `letters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_sent` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sender` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `sender_name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `receiver` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL DEFAULT '',
  `subject` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date_sent` (`date_sent`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `letters` VALUES
(1, '2014-11-23 17:31:27', '2014-11-23 17:31:41', 'ottofonf@gmail.com', 'Дмитрий Смаль', 'ottofonf@gmail.com', 'Первая пробная рассылка', '<body style=\"margin:0; padding:0; font:14px/18px Arial\">\r\n<div style=\"margin:auto; width:800px; padding:20px\">\r\n\r\n	<div style=\"\">Текст в шапке рассылки</div>\r\n	<div style=\"width:0px; height:10px; font:0px/0px Arial; clear:both\"></div>\r\n\r\n	<div style=\"\">текст первой рассылки\r\n<br />\r\nвот такой</div>\r\n	<div style=\"width:0px; height:10px; font:0px/0px Arial; clear:both\"></div>\r\n\r\n	<div style=\"\">Текст в подвале рассылки</div>\r\n	<div style=\"width:0px; height:10px; font:0px/0px Arial; clear:both\"></div>\r\n\r\n	<div style=\"font:11px/15px Arial\">\r\n		Если вы хотите отписаться от рассылки нажмите на 		<a href=\"http://_abc/podpiska/unsubscribe/ottofonf@gmail.com/c5e5cb539d05511405ce755ecf21b2f9/\">ссылку</a>\r\n	</div>\r\n\r\n</div>\r\n</body>'),
(2, '2014-11-23 17:31:27', '2014-11-23 17:47:12', 'ottofonf@gmail.com', 'Дмитрий Смаль', 'ottofonf@rambler.ru', 'Первая пробная рассылка', '<body style=\"margin:0; padding:0; font:14px/18px Arial\">\r\n<div style=\"margin:auto; width:800px; padding:20px\">\r\n\r\n	<div style=\"\">Текст в шапке рассылки</div>\r\n	<div style=\"width:0px; height:10px; font:0px/0px Arial; clear:both\"></div>\r\n\r\n	<div style=\"\">текст первой рассылки\r\n<br />\r\nвот такой</div>\r\n	<div style=\"width:0px; height:10px; font:0px/0px Arial; clear:both\"></div>\r\n\r\n	<div style=\"\">Текст в подвале рассылки</div>\r\n	<div style=\"width:0px; height:10px; font:0px/0px Arial; clear:both\"></div>\r\n\r\n	<div style=\"font:11px/15px Arial\">\r\n		Если вы хотите отписаться от рассылки нажмите на 		<a href=\"http://_abc/podpiska/unsubscribe/ottofonf@rambler.ru/adebd7e8bd633da8589c21702dd496d3/\">ссылку</a>\r\n	</div>\r\n\r\n</div>\r\n</body>');

DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ИД',
  `date` datetime NOT NULL COMMENT 'дата создания лога',
  `user` int(10) unsigned NOT NULL COMMENT 'ИД юсера который вносил изменения',
  `module` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'модуль в котором внесли изменения',
  `parent` int(10) unsigned NOT NULL COMMENT 'ИД редактируемой записи',
  `type` tinyint(1) unsigned NOT NULL COMMENT 'тип действия (создание, редактирование, удаление))',
  PRIMARY KEY (`id`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=60 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */ COMMENT='Логи';

INSERT INTO `logs` VALUES
(1, '2016-01-22 14:53:56', 2, 'contests', 0, 1),
(2, '2016-01-22 14:56:11', 2, 'contests', 1, 1),
(3, '2016-01-22 14:56:27', 2, 'contests', 1, 2),
(4, '2016-01-22 17:12:24', 2, 'olympiads', 1, 1),
(5, '2016-01-22 17:13:04', 2, 'olympiads_tests', 1, 1),
(6, '2016-01-22 17:13:21', 2, 'olympiads', 1, 2),
(7, '2016-01-22 17:15:52', 2, 'olympiads', 2, 1),
(8, '2016-01-22 17:16:52', 2, 'contests', 2, 1),
(9, '2016-01-22 17:18:03', 2, 'publications', 1, 1),
(10, '2016-01-22 17:19:06', 2, 'tests', 1, 1),
(11, '2016-01-23 08:48:18', 2, 'languages', 1, 2),
(12, '2016-01-24 16:09:28', 2, 'pages', 7, 2),
(13, '2016-01-24 16:09:28', 2, 'pages', 7, 2),
(14, '2016-01-24 16:09:29', 2, 'pages', 24, 2),
(15, '2016-01-24 16:09:53', 2, 'pages', 8, 2),
(16, '2016-01-24 16:09:57', 2, 'pages', 8, 2),
(17, '2016-01-24 16:09:59', 2, 'pages', 8, 2),
(18, '2016-01-24 16:10:00', 2, 'pages', 8, 2),
(19, '2016-01-24 16:10:09', 2, 'pages', 7, 2),
(20, '2016-01-24 16:10:34', 2, 'pages', 24, 2),
(21, '2016-01-24 16:11:23', 2, 'pages', 8, 2),
(22, '2016-01-24 16:11:24', 2, 'pages', 7, 2),
(23, '2016-01-24 16:13:26', 2, 'pages', 13, 2),
(24, '2016-01-24 16:13:28', 2, 'pages', 13, 2),
(25, '2016-01-24 16:13:35', 2, 'pages', 8, 2),
(26, '2016-01-24 16:13:35', 2, 'pages', 7, 2),
(27, '2016-01-25 10:09:14', 2, 'languages', 1, 2),
(28, '2016-01-25 10:12:42', 2, 'pages', 24, 2),
(29, '2016-01-25 10:16:34', 2, 'pages', 24, 2),
(30, '2016-01-25 10:17:02', 2, 'pages', 24, 2),
(31, '2016-01-25 10:17:28', 2, 'pages', 24, 2),
(32, '2016-01-25 10:17:48', 2, 'pages', 24, 2),
(33, '2016-01-25 10:18:15', 2, 'pages', 24, 2),
(34, '2016-01-25 10:18:28', 2, 'pages', 24, 2),
(35, '2016-01-25 14:13:03', 2, 'languages', 1, 2),
(36, '2016-01-25 14:14:41', 2, 'languages', 1, 2),
(37, '2016-01-28 09:32:32', 2, 'pages', 8, 2),
(38, '2016-01-28 11:56:15', 2, 'pages', 7, 2),
(39, '2016-01-28 12:00:57', 2, 'pages', 7, 2),
(40, '2016-01-28 12:01:46', 2, 'pages', 7, 2),
(41, '2016-01-28 12:02:02', 2, 'pages', 7, 2),
(42, '2016-01-28 12:02:12', 2, 'pages', 7, 2),
(43, '2016-01-28 12:02:32', 2, 'pages', 7, 2),
(44, '2016-01-28 12:03:03', 2, 'pages', 7, 2),
(45, '2016-01-28 12:04:41', 2, 'pages', 7, 2),
(46, '2016-01-28 12:05:34', 2, 'pages', 7, 2),
(47, '2016-01-28 12:06:03', 2, 'pages', 7, 2),
(48, '2016-01-28 12:08:01', 2, 'pages', 7, 2),
(49, '2016-01-28 12:08:12', 2, 'pages', 7, 2),
(50, '2016-01-28 12:08:24', 2, 'pages', 7, 2),
(51, '2016-01-28 12:08:57', 2, 'pages', 7, 2),
(52, '2016-01-28 12:09:46', 2, 'pages', 7, 2),
(53, '2016-01-28 12:11:50', 2, 'pages', 8, 2),
(54, '2016-01-28 12:12:59', 2, 'pages', 8, 2),
(55, '2016-01-28 12:14:06', 2, 'pages', 8, 2),
(56, '2016-01-28 12:15:54', 2, 'pages', 8, 2),
(57, '2016-01-28 12:16:04', 2, 'pages', 8, 2),
(58, '2016-01-28 12:28:01', 2, 'pages', 8, 2),
(59, '2016-01-28 12:28:16', 2, 'pages', 8, 2);

DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime DEFAULT NULL,
  `user` int(10) unsigned NOT NULL COMMENT 'автор новости',
  `display` tinyint(1) NOT NULL COMMENT 'показывать/скрыть',
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `user` (`user`),
  KEY `display` (`display`)
) ENGINE=MyISAM AUTO_INCREMENT=18 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */ COMMENT='Новости';

INSERT INTO `news` VALUES
(1, '2010-12-28 20:39:51', 2, 1, 'В Швеции уборщица угнала поезд', '<p>Такое можно увидеть не часто &ndash; в Швеции уборщица, по непонятным причинам, угнала поезд, свела его с рельсов и врезалась в жилой дом. К счастью, никто, кроме женщины, в результате не пострадал.&nbsp;<br /><br />Инцидент произошёл 15 января 2012 года. Согласно полиции, женщина, возрастом в районе 20-30 лет, которая работала уборщицей в местной транспортной компании, угнала поезд рано утром. Как именно она получила ключ от поезда, не сообщается.&nbsp;<br /><br />Уборщица вела поезд па большой скорости, свела его с рельсов и врезалась в дом&raquo; - сказал пресс-секретарь организации &laquo;городской транспорт Стокгольма&raquo; Джаспер Петтерссон (Jesper Pettersson).</p>', 'В Швеции уборщица угнала поезд', 'v-shvetsii-uborshchitsa-ugnala-poezd', 'поезд, не, угнала, уборщица, его, врезалась, швеции, свела, дом, рельсов, можно, счастью, непонятным, такое, увидеть, жилой, причинам, часто, по', 'Такое можно увидеть не часто в Швеции уборщица, по непонятным причинам, угнала поезд, свела его с рельсов и врезалась в жилой дом. К счастью,'),
(2, '2011-11-04 12:59:28', 1, 1, 'Белый Дом не даст денег на Звезду Смерти', '<p>Администрация президента США официально отказалась запустить программу по созданию космической станции \"Звезда смерти\" (Death Star), сообщает NBCNews в пятницу, 11 января.<br /><br />Петиция с просьбой о постройке \"Звезды смерти\" была обнародована в декабре 2012 года в рамках программы законотворческих инициатив избирателей \"We the People\". Свои подписи под петицией поставили более 25 тысяч человек после чего, по правилам \"We the People\", администрация президента была обязана рассмотреть обращение и дать на него ответ.<br /><br />Отвечать на петицию о строительстве \"Звезды смерти\" пришлось главе департамента науки и космоса Административно-бюджетного управления Белого дома Полу Шоукроссу (Paul Shawcross). Он назвал как минимум три причины, по которым этот проект не будет реализован: 1. \"Строительство \"Звезды смерти\" обойдется в 850 квадриллионов долларов, а мы стараемся сократить бюджетный дефицит, а не увеличить его\"; 2. \"Администрация президента не поддерживает идею уничтожения планет\"; 3. \"Зачем тратить огромные средства налогоплательщиков на \"Звезду смерти\" с фундаментальным недостатком, которым сможет воспользоваться пилот одноместного космического корабля?\".<br /><br />Далее Шоукросс кратко перечислил основные направления, по которым развивается американская программа по исследованию космоса, упомянув Международную космическую станцию и марсоходы, в том числе оснащенные лазерной пушкой. В заключение он пожелал автору петиции найти себе применение в сфере науки, технологии, инженерии или математики, пообещав, что в этом случае \"с ним пребудет Сила\".<br /><br />На отказ от строительства \"Звезды смерти\" уже отреагировал пользователь твиттера \"Дарт Вейдер\", написавший: \"Серьезная ошибка, господин президент! Лазеров размером с планету всегда не хватает\".</p>', 'Белый Дом не даст денег на Звезду Смерти', 'belyi-dom-ne-dast-deneg-na-zvezdu-smerti', 'смерти, по, на, не, президента, администрация, звезды, которым, сообщает, star, death, космоса, звезда, была, people, он, звезду, станции, науки', 'Администрация президента США официально отказалась запустить программу по созданию космической станции \"Звезда смерти\" (Death Star), сообщает'),
(3, '2011-11-04 13:03:33', 1, 1, 'Грабитель пожаловался полиции на домовладельца с пистолетом', '<p>В американском городе Спрингтаун, штат Техас, был арестован грабитель, который сам позвонил в полицию, чтобы пожаловаться на владельца дома, который задержал его, используя оружие.&nbsp;<br /><br />Подозреваемый Кристофер Мур (Christopher Moore) позвонил в полицию после неудавшегося ограбления. Пока мужчина сидел в своём автомобиле, припаркованном у дома, владелец дома Джеймс Героу (James Gerow) и его сын подошли к нему и навели на него пистолеты.<br /><br />Испуганный Мур позвонил в полицию и сказал им, что двое мужчин держат его в автомобиле, угрожая оружием. В это время жена владельца дома сама позвонила в полицию и подтвердила слова Мура, но добавила, что Мур был преступником, который только что пытался ограбить их дом.</p>', 'Грабитель пожаловался полиции на домовладельца с пистолетом', 'grabitel-pozhalovalsya-politsii-na-domovladeltsa-s-pistoletom', 'полицию, позвонил, который, дома, на, грабитель, мур, владельца, его, что, был, пожаловаться, сам, чтобы, автомобиле, городе, американском', 'В американском городе Спрингтаун, штат Техас, был арестован грабитель, который сам позвонил в полицию, чтобы пожаловаться на владельца'),
(4, '2011-11-04 13:14:48', 1, 1, 'Бог велел женщине нарушить ПДД', '<p>В американском городе Форт-Пирc, штат Флорида, была арестована женщина, которая совершила несколько нарушений ПДД. Женщина сказала полицейским, что нарушила правила дорожного движения \"по указаниям Бога\".<br /><br />41-летняя Мелисса Миллер (Melissa Miller) была арестована. Полицейские остановили её, когда она ехала со скоростью 100 миль в час по дороге с ограничением скорости до 30 миль в час и постоянно сигналила.&nbsp;<br /><br />Когда полицейские спросили её, почему она нарушила правила, она сказала, что \"её направлял Святой Дух\", а сигналила она потому, что &laquo;ей Бог велел так поступить&raquo;.</p>', 'Бог велел женщине нарушить ПДД', 'bog-velel-zhenshchine-narushit-pdd', 'женщина, она, арестована, сказала, была, что, пдд, правила, нарушила, час, полицейские, городе, когда, велел, по, сигналила, нарушений, флорида', 'В американском городе Форт-Пирc, штат Флорида, была арестована женщина, которая совершила несколько нарушений ПДД. Женщина сказала'),
(5, '2011-11-05 13:25:56', 1, 1, 'Мужчина с ведром на голове ограбил ресторан', '<p>Любой более-менее умный грабитель знает, что успешное ограбление требует хорошей маскировки. Один грабитель в США понял это слишком поздно и решил импровизировать, надев на голову ведро.&nbsp;<br /><br />В надежде заработать быстрых денег, 23-летний Ричард Будроу (Richard Boudreaux) решил ограбить какое-нибудь заведение рядом со своим домом в городе Слиделл, штат Луизиана.&nbsp;<br /><br />Целью мужчины стал ресторан морской кухни, в котором он работал. Он пробрался в ресторан ночью, но вспомнил, что в ресторане были установлены камеры скрытого видео-наблюдения. Будроу понял, что не взял с собой никакой маски, чтобы прикрыть лицо, и что он может засветиться.<br /><br />Преступник решил исправить ситуацию, надев на голову ведро, однако сделал он это слишком поздно &ndash; одна из камер успела снять его лицо. После инцидента полицейские быстро нашли мужчину и арестовали его.<br /><br />&laquo;Будроу довольно хорошо подготовился к ограблению &ndash; он надел перчатки, чтобы не оставлять отпечатков, взял с собой различные инструменты для взлома дверей&raquo; - сказал пресс-секретарь местной полиции. &laquo;Однако он забыл про одну важную вещь &ndash; спрятать своё лицо. Он надел на голову ведро, уже находясь внутри ресторана, но камеры успели заснять его лицо&raquo;.</p>', 'Мужчина с ведром на голове ограбил ресторан', 'muzhchina-s-vedrom-na-golove-ograbil-restoran', 'он, что, лицо, грабитель, на, голову, будроу, ведро, понял, слишком, это, ресторан, его, решил, взял, но, надел, камеры, не, собой, поздно, чтобы', 'Любой более-менее умный грабитель знает, что успешное ограбление требует хорошей маскировки. Один грабитель в США понял это слишком'),
(9, '2011-11-05 13:30:21', 1, 1, 'Американец хотел обворовать магазин, чтобы понравиться девушке', '<p>Некоторые люди говорят, что в наше время больше не существует джентльменов, способных достойно ухаживать за девушками, но они ошибаются &ndash; этот мужчина был готов на всё, лишь бы угодить любимой девушке.<br /><br />48-летний американец Джеймс Фленнекен (James Flenniken), житель города Сарасота, штат Флорида, решил тщательно подготовиться к свиданию с девушкой &ndash; он попытался украсть из магазина Walmart вино и бифштексы, чтобы устроить романтический ужин.<br /><br />Но его план не удался. Когда он попытался вынести еду и вино из магазина не заплатив, его задержали охранники. Работники магазина вызвали полицию, и Фленнекен был арестован.<br /><br />Полицейские сказали, что когда они спросили у него, почему он попытался украсть еду, он был ничуть не смущён, и сказал им, что просто хотел &laquo;понравиться девушке&raquo;. На данный момент он находится под стражей в местной тюрьме</p>', 'Американец хотел обворовать магазин, чтобы понравиться девушке', 'amerikanets-hotel-obvorovat-magazin-chtoby-ponravitsya-devushke', 'не, он, что, магазина, девушке, попытался, но, они, был, ошибаются, еду, когда, вино, фленнекен, американец, украсть, из, за, на, девушками, люди', 'Некоторые люди говорят, что в наше время больше не существует джентльменов, способных достойно ухаживать за девушками, но они ошибаются'),
(10, '2011-11-05 13:30:26', 1, 1, 'Американец хотел оживить тело умершего отца', '<p>В американском городе Детроит, штат Мичиган, был арестован мужчина, который похитил с кладбища тело своего покойного отца, надеясь оживить его.&nbsp;<br /><br />Инцидент произошёл 14 января 2013 года. 48-лктний Винцент Брайт (Vincent Bright) и ещё один мужчина, имя которого не было афишировано, пришли на кладбище и вырыли тело покойного Кларенса Брайта (Clarence Bright), который был похоронён несколько часов назад.&nbsp;<br /><br />Полицейские, по информации, полученной от свидетелей и членов семьи Брайта, посчитали Винцента основным подозреваемым и прибыли к нему домой. Тело покойного мужчины было найдено в морозильной камере в подвале дома, а Винцент был арестован. Также полицейские арестовали мужчину, который помогал Винценту.&nbsp;<br /><br />Брайт рассказал полицейским, что украл тело отца из кладбища, надеясь, что он &laquo;чудом восстанет из мёртвых&raquo;.</p>', 'Американец хотел оживить тело умершего отца', 'amerikanets-hotel-ozhivit-telo-umershego-ottsa', 'тело, был, который, отца, покойного, мужчина, арестован, оживить, кладбища, надеясь, что, из, винцент, было, брайта, bright, брайт, полицейские', 'В американском городе Детроит, штат Мичиган, был арестован мужчина, который похитил с кладбища тело своего покойного отца, надеясь оживить'),
(12, '2013-05-27 23:44:20', 0, 1, 'Американец заехал прямо в ресторан, чтобы заказать еду', '<p>Вместо того чтобы подъехать к окошку для обслуживания автомобилистов, чтобы заказать пиццу, один житель США въехал прямо внутрь ресторана, протаранив входную дверь.<br /><br />Работники ресторана быстрого питания Valentino\'s Pizza shop в городе Линкольн, штат Небраска, были немало напуганы странным клиентом, который врезался в здание ресторана и попытался сделать заказ, как ни в чём не бывало.&nbsp;<br /><br />Мужчина, имя которого не было афишировано, был доставлен в госпиталь, когда на место прибыли полицейские и скорая помощь, но о том, получил ли он какие-либо повреждения, ничего не сообщается.<br /><br />Один из свидетелей необычного инцидента сказал, что мужчина был вовсе не смущён произошедшим, как будто делает так каждый день, и не похоже, чтобы в тот момент он был пьян.</p>', 'Американец заехал прямо в ресторан, чтобы заказать еду', 'amerikanets-zaehal-pryamo-v-restoran-chtoby-zakazat-edu', 'чтобы, не, ресторана, один, заказать, прямо, был, сша, житель, въехал, мужчина, он, пиццу, внутрь, как, вместо, автомобилистов, того, подъехать', 'Вместо того чтобы подъехать к окошку для обслуживания автомобилистов, чтобы заказать пиццу, один житель США въехал прямо внутрь'),
(13, '2013-05-27 23:44:51', 0, 1, 'Вместо ювелирного магазина грабители попали в KFC', '<p>В австралийском городе Бьюдесерт были арестованы два грабителя, которые &laquo;ошиблись помещением&raquo; - преступники планировали ограбить ювелирный магазин, но по ошибке пробрались в ресторан быстрого питания KFC.&nbsp;<br /><br />Согласно газете ABC News, ограбление произошло 31 декабря, 2012 года. Дуэйн Дулан (Dwayne Doolan) и Питер Уэлш (Peter Welsh) хотели попасть в ювелирный магазин, проломив стену в здание, но они проломили её не в том месте, и попали в находящийся радом ресторан KFC.<br /><br />Хоть план и провалился, преступники не захотели уходить с пустыми руками, и решили ограбить ресторан. Угрожая металлической трубой, мужчины приказали работникам ресторана отдать им деньги. Получив две с половиной тысячи долларов, преступники сбежали.&nbsp;<br /><br />Работники ресторана вызвали полицию, и, так как преступники ушли с места преступления пешком, полицейские нашли их не далеко от места преступления. Они были арестованы по обвинению в вооружённом ограблении. На данный момент они находятся под стражей.</p>', 'Вместо ювелирного магазина грабители попали в KFC', 'vmesto-yuvelirnogo-magazina-grabiteli-popali-v-kfc', 'преступники, были, ограбить, арестованы, ресторан, они, не, места, планировали, ювелирный, преступления, по, ресторана, магазин, но', 'В австралийском городе Бьюдесерт были арестованы два грабителя, которые ошиблись помещением - преступники планировали ограбить'),
(14, '2013-05-27 23:45:15', 0, 1, 'Преступник оставил за собой след из чипсов Сheetos', '<p>В американском городе Колумбия, штат Южная Каролина, был арестован мужчина, который ограбил магазин, и оставил за собой длинный след кукурузных чипсов Сheetos, который привёл полицейских прямо к его дому.&nbsp;<br /><br />Согласно полиции, 19-литний Остин Ли Уэстфол Преслер (Austin Lee Westfall Presler) ограбил магазин 6 января 2012 года. Он разбил окно, пробрался в магазин и взял пиво, сигареты, закуски и энергетические напитки.&nbsp;<br /><br />Но полицейские быстро нашли Преслера по его собственной вине &ndash; в спешке мужчина нечаянно продырявил несколько упаковок чипсов Сheetos, и след из чипсов и крошек привёл полицейских прямо к входной двери дома знакомого Преслера, у которого он гостил.&nbsp;<br /><br />Полицейские нашли Преслера внутри дома вместе с украденными вещами и арестовали его по обвинению в ограблении. На данный момент он находится под стражей в местной тюрьме. Владелец магазина сказал, что вещи, которые украл Преслер, стоили очень мало &ndash; гораздо дороже ему обойдётся починка окна.</p>', 'Преступник оставил за собой след из чипсов Сheetos', 'prestupnik-ostavil-za-soboi-sled-iz-chipsov-sheetos', 'магазин, след, чипсов, ограбил, преслера, который, мужчина, собой, он, за, сheetos, оставил, его, прямо, нашли, полицейские, полицейских, по', 'В американском городе Колумбия, штат Южная Каролина, был арестован мужчина, который ограбил магазин, и оставил за собой длинный след'),
(17, '2012-10-17 09:09:07', 0, 1, 'еще одна новость', '', 'еще одна новость', 'eshche-odna-novost', 'новость, одна, еще', 'еще одна новость');

DROP TABLE IF EXISTS `olympiads`;
CREATE TABLE `olympiads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` int(10) unsigned NOT NULL,
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  `price2` int(10) unsigned NOT NULL DEFAULT '0',
  `price3` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` smallint(5) unsigned NOT NULL DEFAULT '1',
  `teacher` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `date1` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date2` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `summarizing` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `blank` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `shortdesc` varchar(512) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `file` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category` (`category`),
  KEY `display` (`display`),
  KEY `rank` (`rank`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `olympiads` VALUES
(1, 0, 90, 70, 0, 1, 0, 1, '2016-01-20 00:00:00', '2016-02-28 00:00:00', 'каждую субботу', 'V Международный лексический конкурс \"Word Skills\"', '<div style=\"line-height: 33px;\"><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">В конкурсе по английскому языку могут принять участие учащиеся <strong>1 - 11 классов, студенты.</strong> </span></div>\r\n<div style=\"line-height: 31px;\"><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Задание конкурса состоит в решении кроссворда на английском языке. </span></div>\r\n<div style=\"line-height: 31px;\"><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Цель конкурса: развивать лексические навыки учащихся, совершенствовать </span></div>\r\n<div style=\"line-height: 31px;\"><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">навыки работы со словарем, смекалку, эрудицию. </span></div>', 'v-mezhdunarodnyi-leksicheskii-konkurs-word-skills', 'V Международный лексический конкурс \"Word Skills\"', 'конкурса, студенты, классов, учащиеся, задание, решении, навыки, на, кроссворда, участие, состоит, конкурсе, принять, английскому, по, могут', 'В конкурсе по английскому языку могут принять участие учащиеся 1 - 11 классов, студенты. Задание конкурса состоит в решении кроссворда на', 'crossword-halloween-answers.jpg', '', 'В конкурсе по английскому языку могут принять участие учащиеся 1 - 11 классов, студенты.\r\nЗадание конкурса состоит в решении кроссворда на английском языке.\r\nЦель конкурса: развивать лексические навыки учащихся, совершенствовать\r\nнавыки работы со словарем, смекалку, эрудицию. ', '0.png'),
(2, 0, 90, 70, 0, 1, 0, 1, '1970-01-01 00:00:00', '2016-02-28 00:00:00', 'ежедневно', 'V Международный конкурс творческих работ \"English Short Stories\"', '<div style=\"line-height: 29px;\"><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">В конкурсе могут принять участие учащиеся с 1 по 4 класс.</span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Принимаются художественные переводы с английского языка на русский </span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">язык. </span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Цель конкурса: развивать навыки перевода аутентичных текстов, </span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">развивать навыки чтения, навыки работы со словарем. </span></div>', 'v-mezhdunarodnyi-konkurs-tvorcheskih-rabot-english-short-stories', 'V Международный конкурс творческих работ \"English Short Stories\"', 'навыки, английского, художественные, класс, языка, принимаются, русский, развивать, цель, язык, по, на, переводы, учащиеся, могут, конкурсе', 'В конкурсе могут принять участие учащиеся с 1 по 4 класс.\r\nПринимаются художественные переводы с английского языка на русский язык. Цель', '1335511856_funny-stories.jpg', '', 'В конкурсе могут принять участие учащиеся с 1 по 4 класс.\r\nПринимаются художественные переводы с английского языка на русский\r\nязык.\r\nЦель конкурса: развивать навыки перевода аутентичных текстов,\r\nразвивать навыки чтения, навыки работы со словарем. ', '0.png');

DROP TABLE IF EXISTS `olympiads_tests`;
CREATE TABLE `olympiads_tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `olympiad` int(10) unsigned NOT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT '4',
  `rank` smallint(5) unsigned NOT NULL DEFAULT '1',
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `name` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `file` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `answers` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `olympiad` (`olympiad`),
  KEY `rank` (`rank`),
  KEY `display` (`display`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `olympiads_tests` VALUES
(1, 1, 4, 1, 1, 1, '', 'a:15:{i:1;s:1:\"A\";i:2;s:1:\"A\";i:3;s:1:\"A\";i:4;s:1:\"A\";i:5;s:1:\"A\";i:6;s:1:\"A\";i:7;s:1:\"A\";i:8;s:1:\"A\";i:9;s:1:\"A\";i:10;s:1:\"A\";i:11;s:1:\"A\";i:12;s:1:\"A\";i:13;s:1:\"A\";i:14;s:1:\"A\";i:15;s:1:\"A\";}');

DROP TABLE IF EXISTS `order_deliveries`;
CREATE TABLE `order_deliveries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` tinyint(1) unsigned NOT NULL,
  `rank` int(10) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `cost` decimal(10,2) unsigned NOT NULL,
  `free` decimal(10,2) unsigned NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */,
  PRIMARY KEY (`id`),
  KEY `display` (`display`),
  KEY `rank` (`rank`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `order_payments`;
CREATE TABLE `order_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` tinyint(1) unsigned NOT NULL,
  `merchant` tinyint(1) unsigned NOT NULL,
  `rank` tinyint(4) NOT NULL,
  `name` varchar(255) /*!40101 CHARACTER SET utf8 */ /*!40101 COLLATE utf8_bin */ NOT NULL,
  `text` text /*!40101 CHARACTER SET utf8 */ /*!40101 COLLATE utf8_bin */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `order_types`;
CREATE TABLE `order_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rank` tinyint(3) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `order_types` VALUES
(1, 1, 1, 'новый заказ', 'описание нового заказа'),
(2, 2, 1, 'в обработке', 'ваш заказ обрабатывается нашими менеджерами'),
(3, 3, 1, 'выполненный', 'заказ выполненный');

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `date_paid` datetime NOT NULL,
  `type` tinyint(1) NOT NULL,
  `paid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `place` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `user` int(11) unsigned DEFAULT NULL,
  `parent` int(10) unsigned NOT NULL,
  `email` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `basket` text /*!40101 COLLATE utf8_unicode_ci */,
  `receipt` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `file` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `orders` VALUES
(1, '2016-01-22 17:13:45', '0000-00-00 00:00:00', 1, 0, 0, 2, 1, '', '0.00', 'a:1:{s:7:\"results\";a:1:{i:0;a:0:{}}}', '', '');

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `language` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `parent` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `left_key` int(10) unsigned NOT NULL,
  `right_key` int(10) unsigned NOT NULL,
  `level` smallint(6) DEFAULT '1',
  `display` tinyint(1) NOT NULL,
  `menu` tinyint(1) unsigned NOT NULL,
  `menu2` tinyint(1) unsigned NOT NULL,
  `module` varchar(20) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT 'pages',
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent` (`parent`),
  KEY `rank` (`display`),
  KEY `module` (`module`),
  KEY `left_key` (`left_key`),
  KEY `right_key` (`right_key`),
  KEY `level` (`level`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=26 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */ PACK_KEYS=0;

INSERT INTO `pages` VALUES
(1, 1, 0, 1, 2, 1, 1, 0, 0, 'index', 'Главная', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'index', 'Главная', '', 'Всероссийские дистанционные олимпиады и конкурсы \"Мир-Олимпиад.рф\"', ''),
(2, 1, 0, 21, 22, 1, 1, 0, 0, 'registration', 'Регистрация', '', 'registration', 'Регистрация', 'регистрация', 'Регистрация', ''),
(3, 1, 0, 3, 4, 1, 1, 0, 1, 'profile', 'Личный кабинет', '<p><span style=\"font-size: 18pt; font-family: times new roman,times;\">Выберите нужный раздел слева. </span></p>\r\n<p><span style=\"font-family: times new roman,times; font-size: 18pt;\"><strong><span style=\"font-family: times new roman,times;\">&nbsp;</span></strong></span></p>\r\n<p><span style=\"font-family: times new roman,times; font-size: 18pt; color: #000000;\"><strong><span style=\"font-family: times new roman,times;\">Если у Вас есть вопросы по работе с системой нажмите кнопку <span style=\"color: #ff0000;\"><a href=\"/profile/help/\"><span style=\"color: #ff0000;\">\"Помощь\"</span></a></span></span></strong></span></p>', 'profile', 'Личный кабинет', 'кабинет, личный', 'Личный кабинет', ''),
(4, 1, 0, 23, 24, 1, 1, 0, 0, 'login', 'Вход', '<p>Для продолжения заказа нужна регистрация!<br />Пройдите регистрацию или авторизуйтесь, если вы уже зарегистрированы</p>', 'login', 'Вход', 'вход', 'Вход', ''),
(7, 1, 0, 17, 18, 1, 1, 1, 1, 'pages', 'О нас', '<div style=\"line-height: 27px;\">\r\n<table style=\"height: 260px;\" width=\"1145\">\r\n<tbody>\r\n<tr>\r\n<td><img src=\"/uploads/tumblr_inline_my997vydxT1ryytr3.jpg\" alt=\"\" width=\"325\" height=\"243\" /></td>\r\n<td style=\"padding-left: 30px;\">\r\n<p><span style=\"color: #000000; font-family: times new roman,times; font-size: 18pt;\">Основной деятельностью международного портала дистанционных проектов по английскому языку <strong>&laquo;Англиус&raquo;</strong> является проведение дистанционных конкурсов, олимпиад для школьников на территории стран СНГ.</span></p>\r\n<p><span style=\"color: #000000; font-family: times new roman,times; font-size: 18pt;\"><span style=\"font-family: times new roman,times; font-size: 18pt;\">Миссия портала - повышение мотивации школьников с к изучению английского языка как средства международного общения в глобальном обществе.</span></span></p>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n</div>\r\n<div style=\"line-height: 27px;\">\r\n<p><span style=\"font-family: times new roman,times; font-size: 18pt;\"><span style=\"color: #000000; font-family: times new roman,times; font-size: 18pt;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span></p>\r\n<p><span style=\"color: #000000; font-family: times new roman,times; font-size: 18pt;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Цели портала: развитие креативности молодежи, повышение коммуникативных навыков общения, воспитание толерантности к иноязычной культуре и традициям других, в том числе европейских, стран.</span></p>\r\n</div>\r\n<div style=\"line-height: 27px;\">&nbsp;</div>\r\n<div style=\"line-height: 27px;\"><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\"><span style=\"font-family: times new roman,times; font-size: 18pt;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </span><em>Победители и призеры конкурсов получают сертификаты и дипломы в электронном виде, а учителя, задействованные в подготовке и проведении конкурсов - благодарственные письма.</em></span></div>\r\n<div style=\"line-height: 27px;\">&nbsp;</div>\r\n<div style=\"line-height: 27px;\">\r\n<p><span style=\"font-family: times new roman,times; font-size: 18pt; color: #000000;\">Потрал \"Англиус\" проводит Международные и Всероссийские мероприятия в соответствии с ч. 2 ст. 77 и п. 22 ст. 34 Федерального закона Российской Федерации \"Об образовании в Российской Федерации\" № 273-ФЗ от 29.12.2012 г. (в ред. от 31.12.2014) направленные на поддержку творческого потенциала педагогических работников и обучающихся.</span></p>\r\n<p><span style=\"color: #000000; font-size: 18pt;\">&nbsp;</span></p>\r\n<p><span style=\"font-family: times new roman,times; font-size: 18pt; color: #000000;\">Категории конкурсов разработаны с учетом требований Федеральных государственных стандартов образования (ФГОС).</span></p>\r\n<p><span style=\"color: #000000; font-size: 18pt;\">&nbsp;</span></p>\r\n<p><span style=\"font-family: times new roman,times; font-size: 18pt; color: #000000;\">Наши Конкурсы актуальны, интересны &ndash; они повышают самооценку педагогов; помогают развитию мышления, интеллекта, полезных навыков детей; дают блестящую возможность пополнения Портфолио педагогов и их воспитанников.</span></p>\r\n<p><span style=\"color: #000000; font-size: 18pt;\">&nbsp;</span></p>\r\n<p><span style=\"font-family: times new roman,times; font-size: 18pt; color: #000000;\">Конкурсы проводятся в заочной форме. Участвовать можно как в одном Конкурсе, так и в нескольких Конкурсах. Одна и та же конкурсная работа может участвовать в Конкурсе только в одной номинации. По желанию участника эта же работа может быть выдвинута и в другом Конкурсе &ndash; по новой заявке и оплате.</span></p>\r\n</div>\r\n<p><span style=\"color: #000000; font-size: 18pt;\">&nbsp;</span></p>\r\n<p><span style=\"font-family: times new roman,times; color: #000000; font-size: 18pt;\"><strong>По всем вопросам обращайтесь:</strong></span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">e-mail: info@anglius.ru</span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">город Краснодар</span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"font-family: times new roman,times; color: #000000; font-size: 18pt;\"><strong>Руководитель проекта:</strong></span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">Прасол Анна Евгеньевна, учитель английского языка высшей категории.</span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"font-family: times new roman,times; color: #000000; font-size: 18pt;\"><strong>Организатор:</strong></span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">Индивидуальный предприниматель Прасол Сергей Владимирович</span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">ИНН 234105879373</span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">ОГРН 315237100001820</span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\"><strong>Подтверждающие документы</strong></span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">Подтверждающие документы участников конкурсов, олимпиад, содержат следующие данные и реквизиты: указание на Организатора мероприятия, результат участия, серию, номер, ФИО Участника, должность, наименование представляемой организации, её местонахождение, название мероприятия, название номинации, возрастную категорию (если есть), название конкурсной работы, ФИО руководителя (если есть), дату проведения мероприятия, печать и подпись Организатора.</span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">Дипломы, Сертификаты, выдаваемые дистанционным порталом &laquo;Мир-Олимипад&raquo;, являются подтверждающими документами при аттестации согласно Порядку проведения аттестации педагогических работников организаций, осуществляющих образовательную деятельность, утвержденному приказом Минобрнауки РФ от 07.04.2014 г. № 276, и входят в перечень документов и материалов портфолио воспитателя, учителя и других педагогических работников, необходимых для проведения оценки профессиональной деятельности.</span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">С помощью них можно также сформировать портфолио достижений дошкольника, школьника.</span></p>\r\n<p><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">&nbsp;</span></p>\r\n<p style=\"text-align: center;\"><span style=\"color: #000000; font-size: 18pt;\"><em><span style=\"font-family: times new roman,times;\">Уважаемые Педагоги и Школьники! Мы всегда искренне рады видеть Вас в качестве участников нашего конкурса! Участвуйте в наших мероприятиях и развивайтесь!</span></em></span></p>\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n<p style=\"text-align: center;\"><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p style=\"text-align: center;\"><a href=\"http://минобрнауки.рф/\" target=\"_blank\"><span style=\"color: #000000;\"><img src=\"/uploads/minobr.jpg\" alt=\"\" width=\"540\" height=\"237\" /></span></a></p>\r\n<p style=\"text-align: center;\">&nbsp;</p>\r\n<p style=\"text-align: center;\">&nbsp;</p>', 'o-nas', 'О нас', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor', ''),
(17, 1, 0, 7, 8, 1, 1, 1, 1, 'tests', 'Конкурсы учителей', '<p><span style=\"font-family: times new roman,times; font-size: 18pt;\"><strong>Постоянные конкурсы учителей с ускоренными сроками подведения итогов.</strong></span></p>\r\n<p><span style=\"text-decoration: underline;\"><span style=\"font-family: times new roman,times; font-size: 14pt;\">Все участники конкурса награждаются Дипломами 1, 2, 3 степени.</span></span></p>\r\n<p><span style=\"font-family: times new roman,times; font-size: 14pt;\">&nbsp;Работы принимаются постоянно. Жюри оценивает работы в течение ДВУХ рабочих дней. После чего результаты можно будет увидеть в личном кабинете.</span></p>\r\n<p><span style=\"font-family: times new roman,times; font-size: 14pt;\">&nbsp;<strong>В Конкурсе могут принять участие педагогические работники любых образовательных учреждений, в том числе и дошкольных.</strong></span></p>\r\n<p style=\"text-align: center;\"><span style=\"font-family: times new roman,times; font-size: 18pt;\"><strong>Примеры наших дипломов:</strong></span></p>\r\n<p style=\"text-align: center;\"><span style=\"font-family: times new roman,times; font-size: 14pt;\"><strong><img src=\"/uploads/dip.jpg\" alt=\"\" width=\"182\" height=\"258\" /> <img src=\"/uploads/dip.jpg\" alt=\"\" width=\"182\" height=\"258\" /> <img src=\"/uploads/dip.jpg\" alt=\"\" width=\"182\" height=\"258\" /></strong></span></p>\r\n<p><span style=\"color: #000000; font-family: \'Times New Roman\'; font-size: 21px;\"><strong><span style=\"text-decoration: underline;\">Стоимость участия 100 рублей.</span></strong></span></p>\r\n<p><span style=\"color: #000000; font-family: \'Times New Roman\'; font-size: 20px;\"><strong>При участии в нескольких конкурсах можно оплачивать одним платежом.</strong></span></p>\r\n<p><span style=\"color: #000000; font-family: \'Times New Roman\'; font-size: 20px;\"><strong><span style=\"text-decoration: underline;\">ВНИМАНИЕ! Для участников стран СНГ оплата оргвзноса возможна только путем денежных переводов систем: Колибри, Золотая Корона, Юнистрим. Безадресный перевод на имя: Прасол Сергей Владимирович.</span></strong></span></p>', 'konkurs-uchitelei', 'Конкурс учителей', 'учителей, конкурс', 'Конкурс учителей', 'icon-5.png'),
(8, 1, 0, 15, 16, 1, 1, 1, 1, 'pages', 'Оплата', '<p><span style=\"font-size: 24pt; font-family: times new roman,times;\"><strong><span style=\"color: #0000ff;\"><span style=\"font-size: 18pt;\">На данной старнице содержится информациия о стоимости участия и способах оплаты.</span><br /></span> </strong></span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"color: #000000;\"><span style=\"font-family: times new roman,times; font-size: 19px;\"><strong>Конкурсы для учащихся.</strong> Стоимость участия за одного человека - 90 рублей. </span><span style=\"font-family: \'Bookman Old Style\'; font-size: 19px;\"><span style=\"font-family: times new roman,times;\">От 5 и более участников - 70 рублей.</span><em><br /></em></span></span></p>\r\n<p><span style=\"color: #000000;\"><span style=\"font-family: \'Bookman Old Style\'; font-size: 19px;\"><span style=\"font-family: times new roman,times;\"><strong>Творческие конкурсы.</strong> Стоимость участия - 80 рублей.</span></span></span></p>\r\n<p><span style=\"color: #000000;\"><span style=\"font-family: \'Bookman Old Style\'; font-size: 19px;\"><span style=\"font-family: times new roman,times;\"><strong>Публикация.</strong> Стоимость публикации - 100 рублей.</span></span></span></p>\r\n<p><span style=\"color: #000000;\"><span style=\"font-family: \'Bookman Old Style\'; font-size: 19px;\"><span style=\"font-family: times new roman,times;\"><strong>Конференция учителей.</strong> Стоимость участия - 300 рублей.</span></span></span></p>\r\n<p><span style=\"color: #000000;\"><span style=\"font-size: 14pt; font-family: times new roman,times;\"><strong>Конкурсы для учителей.</strong> Стоимость участия - 100 рублей.</span></span></p>\r\n<p><span style=\"color: #000000;\"><span style=\"font-size: 14pt; font-family: times new roman,times;\"><strong>Олимпиады для учителей.</strong> Стоимость участия - 100 рублей.</span></span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Для участников стран СНГ оплата оргвзноса возможна только путем денежных переводов систем: Колибри, Золотая Корона, Юнистрим. Безадресный перевод на имя: Прасол Сергей Владимирович.</span></p>\r\n<p><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\"><strong>В комментарии к платежу обязательно напишите фамилию координатора, название учреждения и населенный пункт, количество участников.</strong></span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\"><strong>После внесения ответов в олимпиадах не забудьте прикрепить квитанцию об оплате к заявке!</strong></span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\"><strong>Оплатить через</strong> банкомат на Яндекс Кошелек 410011420136160</span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\"><strong>Вы можете оплатить на карту Сбербанка</strong> № 4276 3000 1496 6462, через Сбербанк Онлайн, терминал любого банка или в отделении Сбербанка России</span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\"><strong>Квитанция для оплаты через банк - </strong><span style=\"color: #0000ff;\"><strong><a href=\"http://www.anglius.ru/Как%20оплатить%20anglius.ru.docx\" target=\"_blank\"><span style=\"color: #0000ff;\">скачать</span></a></strong></span></span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\"><strong>Реквизиты для оплаты через банк (банковский терминал):</strong></span></p>\r\n<p><span style=\"font-family: times new roman,times; font-size: 14pt; color: #000000;\">ИП Прасол Сергей Владимирович</span><br /><span style=\"font-family: times new roman,times; font-size: 14pt; color: #000000;\"> ИНН 234105879373</span><br /><span style=\"font-family: times new roman,times; font-size: 14pt; color: #000000;\"> Р/с: 40802810602270001958</span><br /><span style=\"font-family: times new roman,times; font-size: 14pt; color: #000000;\"> Банк: Ф ОНЛАЙН ПАО \"ХАНТЫ-МАНСИЙСКИЙ БАНК ОТКРЫТИЕ\"</span><br /><span style=\"font-family: times new roman,times; font-size: 14pt; color: #000000;\"> Корр. счет: 30101810600000000999</span><br /><span style=\"font-family: times new roman,times; font-size: 14pt; color: #000000;\"> БИК банка 044583999</span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>', 'kak-oplatit', 'Как оплатить', 'оплатить, как', 'Как оплатить', 'icon-6.png'),
(11, 1, 0, 25, 26, 1, 1, 0, 0, 'remind', 'Восстановление пароля', '<p>Введите свой электронный адрес, на него будет выслана информация по восстановлению пароля.</p>', 'remind', 'Восстановление пароля', 'пароля, восстановление', 'Восстановление пароля', ''),
(13, 1, 0, 19, 20, 1, 0, 0, 0, 'feedback', 'Обратная связь', '', 'feedback', 'Обратная связь', 'связь, обратная', 'Обратная связь', ''),
(14, 1, 0, 5, 6, 1, 1, 1, 1, 'olympiads', 'Олимпиады', '', 'olimpiady', 'Олимпиады', 'олимпиады', 'Олимпиады', 'icon-2.png'),
(15, 1, 0, 11, 12, 1, 1, 1, 1, 'contests', 'Творческие конкурсы', '<div class=\"float-left\" style=\"width: 386px; margin-right: 20px;\">\r\n<div class=\"head\">Условия участия:</div>\r\n<p>- Выберите номинацию конкурса<br />- Отправьте заявку участника конкурса.<br /> - Оплатите организационный взнос: 80 рублей. *При совершении электронных платежей не забудьте сделать скриншот экрана по завершении платежной операции.<br /> - Итоги за прошедший конкурс Вы можете посмотреть в разделе \"Мои заказы\"</p>\r\n</div>\r\n<div class=\"float-left\" style=\"width: 386px; margin-right: 20px;\">\r\n<div class=\"head\">Критерии оценки:</div>\r\n<p>- самостоятельность<br />- соответствие выбранной тематике<br />- оригинальность<br /> - логичность изложения<br />- полнота раскрытия темы<br />- аккуратность выполнения работы</p>\r\n</div>\r\n<div class=\"float-left\" style=\"width: 386px;\">\r\n<div class=\"head\">Награждение:</div>\r\nУчастие в конкурсе подтверждается сертификатом участника или дипломом лауреата конкурса.<br /> Победители награждаются дипломами I степени, призеры- дипломами II и III степени.<br /> Дипломы и сертификаты отсылаются на электронные и почтовые адреса, указанные в заявке.</div>\r\n<div class=\"clear-both\">&nbsp;</div>', 'tvorcheskie-konkursy', 'Творческие конкурсы', 'не, что, банк, полицейские, доллар, мужчина, был, его, под, макмуллен, арестовали, на, сказали, он, банка, сказал, но, дал, пенсильвания', 'В американском городе Северная Камбрия, штат Пенсильвания, был арестован не очень амбициозный грабитель, который попытался ограбить банк', 'icon-3.png'),
(24, 1, 0, 13, 14, 1, 1, 1, 1, 'pages', 'Конференции', '<p style=\"text-align: center;\"><span style=\"font-size: 36pt; color: #000000;\"><strong><span style=\"font-family: times new roman,times;\">Уважаемые педагоги!</span></strong></span><br /><span style=\"font-family: times new roman,times; color: #000000;\"><span style=\"font-size: 18pt;\">&nbsp;Приглашаем Вас принять участие в</span> <span style=\"font-size: 24px;\">I Международной Конференции учителей английского языка </span><span style=\"font-size: 18pt;\">по проблеме преподавания английского языка</span> </span></p>\r\n<p style=\"text-align: center;\"><span style=\"font-family: times new roman,times; color: #000000; font-size: 24pt;\">\"<strong>Современные технологии обучения иностранным языкам в контексте ФГОС</strong>\" </span></p>\r\n<p style=\"text-align: center;\"><span style=\"font-family: times new roman,times; color: #000000;\"><span style=\"font-size: 18pt;\">и I Международном педагогическом конкурсе </span></span></p>\r\n<p style=\"text-align: center;\"><span style=\"font-family: times new roman,times; color: #000000; font-size: 24pt;\"><strong>&laquo;Современные технологии обучения иностранным языкам в контексте ФГОС&raquo;</strong></span><br /><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">Заочная форма проведения!</span><br /><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\">Приняв участие в конференции, Вы получаете: <strong>участие в двух мероприятиях и 3 документа международного уровня!!!</strong></span></p>\r\n<p style=\"text-align: center;\"><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">(1.Свидетельство о публикации в сборнике в электронном сборнике; 2. Диплом с указанием призового места соответсвующего работе; 3. Сертификат участника конференции)</span><br /><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\"><span style=\"font-size: 14pt;\">По окончании конференции будет выпущена электронная версия сборника.</span> <br /></span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"color: #000000;\"><strong><span style=\"font-family: times new roman,times; font-size: 18pt;\">Приглашаются к участию в конференции педагоги, студенты педагогических факультетов средних и высших образовательных учреждений.</span></strong></span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: times new roman,times; font-size: 18pt; color: #000000;\">Конференция является комплексной образовательной программой, выраженной в форме сетевого взаимодействия образовательных учреждений, учащихся, учителей из разных стран СНГ.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: times new roman,times; font-size: 18pt; color: #000000;\"><strong>Цель конференции</strong> - обобщение опыта ведущей педагогической общественности из стран СНГ, участвующей в деятельности, направленной на углубленное изучение английского языка; а также развитие системы организации и инфраструктуры изучения языков в образовательных учреждениях. </span></p>\r\n<p><span style=\"font-family: times new roman,times; font-size: 18pt; color: #000000;\">Конференция направлена на приобщение педагогов к современным методам изучения языков, включая интерактивные способы обучения посредством использования компьютерных технологий.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"text-decoration: underline; color: #000000;\"><span style=\"font-size: 18pt; font-family: times new roman,times;\"><strong>Информация о I Международном педагогическом конкурсе.</strong></span></span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Работы участников принимают участие одновременно в двух проектах: конференции и конкурсе.</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Каждая работа рассматривается экспертами. Если работа не соответствует призовому месту,то&nbsp; она отправляется на доработку согласно комментариям.</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Всем принятым работам гарантированно будет присвоено призовое место не ниже III.</span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"text-decoration: underline; color: #000000;\"><strong><span style=\"font-size: 18pt; font-family: times new roman,times;\">Основными критериями оценивания являются следующие направления:</span></strong></span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"font-size: 18pt; font-family: times new roman,times; color: #000000;\"><span style=\"font-size: 14pt;\">Плагиат (Материал должен быть авторским, допускается публикация в других изданиях под именем одного автора. Допускаются совпадения с другими источниками, но не выше 40% с одного источника)</span></span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Соответствие действующим образовательным стандартам</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Актуальность и новизна</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Наличие грамотного оформления (представление целей, обоснование актуальности, логичность материала, наличие списка литературы и пр)</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Прочие критерии согласно направлению работы</span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"text-decoration: underline; color: #000000;\"><strong><span style=\"font-size: 18pt; font-family: times new roman,times;\">Требования к работам:</span></strong></span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">- все работы должны быть представлены в соответствии с действующими образовательными стандартами.</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">- работы должны быть авторскими.</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">- работа может быть представлена несколькими авторами.</span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"text-decoration: underline; color: #000000;\"><strong><span style=\"font-size: 18pt; font-family: times new roman,times;\">Оформление:</span></strong></span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Работа оформляется шрифтом Times New Roman, 12 pt, междустрочный интервал - одинарный</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Работа должна содержать следующие данные:</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">1. Наименование работы (Расположено в верхней части страницы)</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">2. ФИО всех авторов и соавторов - Место работы и должность всех участников работы, город.</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">3. Далее наличие самой работы</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">4. Список литературы</span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"text-decoration: underline; color: #000000;\"><strong><span style=\"font-size: 18pt; font-family: times new roman,times;\">Требование к материалу:</span></strong></span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Материал формируется текстом. Допустимы изображения. Изображения должны быть четкими, качественными, соответствовать представляемому материалу. Изображения плохого качества или не по теме работы будут отклоняться.</span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"text-decoration: underline; color: #000000;\"><strong><span style=\"font-size: 18pt; font-family: times new roman,times;\">Правила отправления работы:</span></strong></span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Нажмите кнопку \"Принять участие\" в начале страницы. </span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Все работы будут опубликованы в электронном сборнике.</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Каждый участник может отправлять любое количество работ.</span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"color: #000000;\"><strong><span style=\"font-size: 18pt; font-family: times new roman,times;\">Работы принимаются до 20.02.2016!</span></strong></span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"color: #000000;\"><strong><span style=\"font-size: 18pt; font-family: times new roman,times;\">Предполагаемое&nbsp; время издания сборника - 28.02.2016</span></strong></span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"text-decoration: underline; color: #000000;\"><strong><span style=\"font-size: 18pt; font-family: times new roman,times;\">Наградные документы будут доступны в личном кабинете сразу после оплаты участия в конференции.</span></strong></span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">Все участники получат следующие документы:</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">&nbsp;&nbsp;&nbsp; \"Сертификат участника педагогической научно-практической конференции\"</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">&nbsp;&nbsp;&nbsp; \"Свидетельство о публикации в электронном сборнике\"</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">&nbsp;&nbsp;&nbsp; \"Диплом с указанием призового места\"</span><br /><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">&nbsp;Все документы будут предоставлены в электронном виде! По необходимости, будет отправлен печатный вариант.</span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p><span style=\"text-decoration: underline; color: #000000;\"><strong><span style=\"font-size: 18pt; font-family: times new roman,times;\">Стоимость участия:</span></strong></span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"font-size: 14pt; font-family: times new roman,times; color: #000000;\">С публикацией в электронном сборнике&nbsp; составляет 400 рублей.</span></p>\r\n<p><span style=\"color: #000000;\">&nbsp;</span></p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>', 'conferences', 'Конференции', 'Конференции', 'Конференции', ''),
(16, 1, 0, 9, 10, 1, 1, 1, 1, 'publications', 'Публикации', '<div class=\"float-left\" style=\"width: 588px; margin-right: 20px;\">\r\n<div class=\"head\">К публикации на сайте мы принимаем следующие материалы:</div>\r\n- каледнадро-тематическое планирование;<br /> - рабочие программы;<br /> - статьи по вопросам преподавания;<br /> - учебно-методические разработки;<br /> - сценарии внеклассных мероприятий в школе,<br /> - сценарии (конспекты) классных часов;<br /> - сценарии праздников, развлечений, игровых и конкурсных программ для школьников и дошкольников;<br /> - обучающие уроки;<br /> - конспекты уроков и презентации;<br /> - мастер-классы;<br /> - оформление учебного кабинета;<br /> - сценарии семинаров, родительских собраний и конференций;<br /> - кроссворды, викторины (обязательно с ответами);<br /> - игры (развивающие, подвижные, дидактические);<br /> - тесты и контрольные работы к урокам.</div>\r\n<div class=\"float-left\" style=\"width: 592px;\">\r\n<div class=\"head\">Требования к оформлению текстовых материалов:</div>\r\n- Текст располагается в формате, пригодном для распечатывания на листах А-4. Поля: сверху, снизу - 2 см, справа 1,5 см., слева - 2,5 см. Размер кегля - 14, межстрочный интервал - одинарный, шрифт - Times New Roman.<br /> - Титульный лист должен содержать следующие сведения: полное наименование учреждения; название темы размещаемого материала; сведения об авторе (Ф.И.О. полностью, должность, место работы).</div>\r\n<div class=\"clear-both\">&nbsp;</div>', 'publikatsii', 'Публикации', 'публикации', 'Публикации', 'icon-4.png'),
(25, 1, 0, 27, 28, 1, 1, 0, 0, 'pages', 'help', '<p><span style=\"font-family: times new roman,times; font-size: 18pt; color: #000080;\"><a href=\"/uploads/%D0%9F%D0%BE%D0%BB%D0%BE%D0%B6%D0%B5%D0%BD%D0%B8%D0%B5%20%D0%BE%D0%B1%20%D0%BE%D0%BB%D0%B8%D0%BC%D0%BF%D0%B8%D0%B0%D0%B4%D0%B5%20%D0%9C%D0%B8%D1%80-%D0%9E%D0%BB%D0%B8%D0%BC%D0%BF%D0%B8%D0%B0%D0%B4.docx\" target=\"_blank\"><span style=\"color: #000080;\">Положение об олимпиадах сайта \"Мир-Олимпиад\"</span></a></span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: times new roman,times; font-size: 18pt;\"><strong><span style=\"font-family: times new roman,times;\">Как и куда загрузить квитанцию?</span></strong></span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"font-family: times new roman,times; font-size: 14pt;\">При участии в олимпиадах - квитанцию можно прикрепить к заявке, только после внесения ответов участников! </span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"font-family: times new roman,times; font-size: 14pt;\">При участии в конкурсах учителей, творческих конкурсах, публикациях - квитанцию можно прикрепить после добавления материала на сайт!</span></p>\r\n<p>&nbsp;</p>\r\n<p><strong><span style=\"font-family: times new roman,times; font-size: 18pt;\">Где можно скачать наградные документы?</span></strong></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"font-family: times new roman,times; font-size: 14pt;\">Перейдите в раздел &laquo;Мои заявки&raquo; - &laquo;Оплаченные&raquo; - найдите нужную Вам заявку и нажмите на нее (либо на кнопку &laquo;Подробнее&raquo;) там Вы увидите ссылки на наградные документы. (Сертификат по ИКТ - компетентности находится внизу страницы).</span></p>\r\n<p>&nbsp;</p>\r\n<p><strong><span style=\"font-family: times new roman,times; font-size: 18pt;\">Когда появятся наградные документы в личном кабинете?</span></strong></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"font-family: times new roman,times; font-size: 14pt;\">Олимпиады: при оплате онлайн - наградные документы появятся сразу после оплаты, если Вы оплатили по квитанции и прикрепили ее к заявке, то наградные документы появятся после проверки модератором квитанции об оплате.</span></p>\r\n<p style=\"padding-left: 30px;\"><span style=\"font-family: times new roman,times; font-size: 14pt;\">Конкурсы учителей, творческие конкурсы, публикации - наградные документы появятся после оценки Ваших работ.</span></p>', 'help', 'help', 'help', 'help', '');

DROP TABLE IF EXISTS `publications`;
CREATE TABLE `publications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `date` datetime NOT NULL,
  `fio` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `workplace` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `file` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `display` (`display`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `publications` VALUES
(1, 1, '2016-01-22 17:17:36', 'Иванов Иван Иванович', 'МБОУ СОШ 100', 'МБОУ СОШ 100', '0.png');

DROP TABLE IF EXISTS `redirects`;
CREATE TABLE `redirects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display` tinyint(1) unsigned NOT NULL,
  `old_url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `new_url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `old_url` (`old_url`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `redirects` VALUES
(1, 1, '/magazin/', '/shop/');

DROP TABLE IF EXISTS `seo_links`;
CREATE TABLE `seo_links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `limit` tinyint(3) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  `keyword` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_bin */;

DROP TABLE IF EXISTS `seo_links-pages`;
CREATE TABLE `seo_links-pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `child` int(10) unsigned NOT NULL,
  `parent` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_bin */;

DROP TABLE IF EXISTS `seo_pages`;
CREATE TABLE `seo_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display` tinyint(3) unsigned NOT NULL,
  `exist` tinyint(1) unsigned NOT NULL COMMENT 'присутствует на сайте',
  `yandex_index` tinyint(1) unsigned NOT NULL,
  `yandex_check` datetime NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  `links` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL COMMENT 'ИД ссылок',
  `articles` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL COMMENT 'ИД статтей',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_bin */;

INSERT INTO `seo_pages` VALUES
(1, 1, 1, 0, '0000-00-00 00:00:00', '/', 'Главная', '145,1,7,154,10', ''),
(2, 1, 1, 0, '0000-00-00 00:00:00', '/korzina/', 'Корзина', '1,26,154,34,639', ''),
(3, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/13-dlya-raboty-i-ucheby/8-Asus N53SV/', 'Asus N53SV', '10,181,145,1,774', ''),
(4, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/13-dlya-raboty-i-ucheby/9-Lenovo IdeaPad B570A/', 'товар', '34,1,186,10,639', ''),
(5, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/dlya-raboty-i-ucheby/9-Lenovo IdeaPad B570A/', 'Каталог', '7,181,10,149,26', ''),
(6, 1, 1, 0, '0000-00-00 00:00:00', '/kontakty/', 'Контакты', '183,10,36,186,2', ''),
(7, 1, 1, 0, '0000-00-00 00:00:00', '/obratnaya-svyaz/', 'Обратная связь', '10,26,2,774,149', ''),
(8, 1, 1, 0, '0000-00-00 00:00:00', '/o-nas/', 'О нас', '181,774,186,36,10', ''),
(9, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/4-telefony/', 'Телефоны', '', ''),
(10, 1, 1, 0, '0000-00-00 00:00:00', '/novosti/', 'Новости', '', ''),
(11, 1, 1, 0, '0000-00-00 00:00:00', '/novosti/14-prestupnik-ostavil-za-soboi-sled-iz-chipsov-sheetos/', 'Преступник оставил за собой след из чипсов Сheetos', '', ''),
(12, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/7-aktivnyi-otdyh-i-turizm/', 'Активный отдых и туризм', '', ''),
(13, 1, 1, 0, '0000-00-00 00:00:00', '/profile/', 'Личный кабинет', '', ''),
(14, 1, 1, 0, '0000-00-00 00:00:00', '/profile/user_edit/', 'Личные данные', '', ''),
(15, 1, 1, 0, '0000-00-00 00:00:00', '/profile/orders/', 'Статистика заказов', '', ''),
(16, 1, 1, 0, '0000-00-00 00:00:00', '/profile/orders/11/', 'Заказ № 11 от 28.06.2015', '', ''),
(17, 1, 1, 0, '0000-00-00 00:00:00', '/login/exit/', 'Авторизация', '', ''),
(18, 1, 1, 0, '0000-00-00 00:00:00', '/galereya/', 'Галерея', '', ''),
(19, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/', 'Каталог', '', ''),
(20, 1, 1, 0, '0000-00-00 00:00:00', '/vakkansii/', 'Ваккансии', '', ''),
(21, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/1-kompyutery-i-noutbuki/', 'Компьютеры и ноутбуки', '', ''),
(22, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/2-noutbuki/', 'Ноутбуки', '', ''),
(23, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/12-nachalnyi-uroven/', 'Начальный уровень', '', ''),
(24, 1, 1, 0, '0000-00-00 00:00:00', '/login/enter/', 'Авторизация', '', ''),
(25, 1, 1, 0, '0000-00-00 00:00:00', '/o-kompanii/', 'О компании', '', ''),
(26, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/13-dlya-raboty-i-ucheby/', 'Для работы и учебы', '', ''),
(27, 1, 1, 0, '0000-00-00 00:00:00', '/katalog/13-dlya-raboty-i-ucheby/7-Acer Aspire 5250-E302G32Mikk/', 'Acer Aspire 5250-E302G32Mikk', '', ''),
(28, 1, 1, 0, '0000-00-00 00:00:00', '/galereya/2-vtoraya/', 'Вторая', '', ''),
(29, 1, 1, 0, '0000-00-00 00:00:00', '/galereya/1-priroda/', 'Природа', '', ''),
(30, 1, 1, 0, '0000-00-00 00:00:00', '/profile/orders/2/', 'Заказ № 2 от 02.04.2014', '', '');

DROP TABLE IF EXISTS `shop_brands`;
CREATE TABLE `shop_brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` tinyint(3) unsigned NOT NULL,
  `rank` int(11) NOT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `display` (`display`),
  KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `shop_brands` VALUES
(1, 1, 0, 'Samsung', 'samsung', 'samsung', 'Samsung', 'Samsung', ''),
(2, 1, 0, 'ASUS', 'asus', 'asus', 'ASUS', 'ASUS', ''),
(3, 1, 0, 'Lenovo', 'lenovo', 'lenovo', 'Lenovo', 'Lenovo', ''),
(4, 1, 0, 'Acer', 'acer', 'acer', 'Acer', 'Acer', '');

DROP TABLE IF EXISTS `shop_categories`;
CREATE TABLE `shop_categories` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `parent` int(10) unsigned NOT NULL DEFAULT '0',
  `left_key` int(10) unsigned NOT NULL,
  `right_key` int(10) unsigned NOT NULL,
  `level` smallint(6) DEFAULT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `parameters` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parent` (`parent`),
  KEY `display` (`display`)
) ENGINE=MyISAM AUTO_INCREMENT=27 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `shop_categories` VALUES
(1, 0, 1, 22, 1, 1, 'Компьютеры и ноутбуки', 'Компьютеры и ноутбуки', 'kompyutery-i-noutbuki', 'ноутбуки, компьютеры', 'Компьютеры и ноутбуки', 'notebooks_687896.jpg', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(2, 1, 2, 11, 2, 1, 'Ноутбуки', 'Ноутбуки', 'noutbuki', 'ноутбуки', 'Ноутбуки', 'notebooks_687896.jpg', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:6;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:3;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:4;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:5;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}}', ''),
(3, 10, 13, 14, 3, 1, 'Серверы', 'Серверы', 'servery', 'серверы', 'Серверы', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:5;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}}', ''),
(14, 10, 17, 18, 3, 1, 'Начальный уровень', 'Начальный уровень', 'nachalnyi-uroven', 'уровень, начальный', 'Начальный уровень', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(4, 0, 23, 28, 1, 1, 'Телефоны', 'Телефоны', 'telefony', 'телефоны', 'Телефоны', '420.jpg', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(5, 4, 24, 25, 2, 1, 'Сотовые телефоны', 'Сотовые телефоны', 'sotovye-telefony', 'телефоны, сотовые', 'Сотовые телефоны', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:4;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:5;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}}', ''),
(6, 4, 26, 27, 2, 1, 'Радиотелефоны', 'Радиотелефоны', 'radiotelefony', 'радиотелефоны', 'Радиотелефоны', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:4;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:5;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}}', ''),
(7, 0, 31, 32, 1, 1, 'Активный отдых и туризм', 'Активный отдых и туризм', 'aktivnyi-otdyh-i-turizm', 'туризм, отдых, активный', 'Активный отдых и туризм', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(8, 2, 7, 10, 3, 1, 'Нетбуки', 'Нетбуки', 'netbuki', 'нетбуки', 'Нетбуки', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(9, 0, 29, 30, 1, 1, 'Бытовая техника, интерьер', 'Бытовая техника, интерьер', 'bytovaya-tehnika-interer', 'интерьер, техника, бытовая', 'Бытовая техника, интерьер', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(10, 1, 12, 21, 2, 1, 'Компьютеры', 'Компьютеры', 'kompyutery', 'компьютеры', 'Компьютеры', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(11, 8, 8, 9, 4, 1, 'Ультрабуки', 'Ультрабуки', 'ultrabuki', 'ультрабуки', 'Ультрабуки', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(12, 2, 3, 4, 3, 1, 'Начальный уровень', 'Начальный уровень', 'nachalnyi-uroven', 'уровень, начальный', 'Начальный уровень', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(13, 2, 5, 6, 3, 1, 'Для работы и учебы', 'Для работы и учебы', 'dlya-raboty-i-ucheby', 'учебы, работы, для', 'Для работы и учебы', '52.png', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:6;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:3;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:4;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}}', ''),
(15, 10, 19, 20, 3, 1, 'Для работы и учебы', 'Для работы и учебы', 'dlya-raboty-i-ucheby', 'учебы, работы, для', 'Для работы и учебы', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(16, 0, 33, 34, 1, 1, 'Товары для детей', 'Товары для детей', 'tovary-dlya-detei', 'детей, для, товары', 'Товары для детей', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(17, 0, 35, 36, 1, 1, 'Дом, сад', 'Дом, сад', 'dom-sad', 'сад, дом', 'Дом, сад', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:5;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}}', ''),
(18, 10, 15, 16, 3, 1, 'Серверы2', 'Серверы', 'servery', 'серверы', 'Серверы', '', 'a:6:{i:1;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:6;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:3;a:3:{s:6:\"filter\";s:1:\"0\";s:7:\"product\";s:1:\"0\";s:7:\"display\";s:1:\"0\";}i:4;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}i:5;a:3:{s:6:\"filter\";s:1:\"1\";s:7:\"product\";s:1:\"1\";s:7:\"display\";s:1:\"1\";}}', '');

DROP TABLE IF EXISTS `shop_items`;
CREATE TABLE `shop_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display` tinyint(1) unsigned NOT NULL,
  `n` tinyint(3) unsigned NOT NULL,
  `parent` int(10) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_bin */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_bin */;

INSERT INTO `shop_items` VALUES
(28, 1, 3, 1, 'Hydrangeas', 'hydrangeas.jpg'),
(21, 1, 1, 1, 'Jellyfish', 'jellyfish.jpg'),
(26, 1, 4, 1, 'Hydrangeas', 'hydrangeas.jpg'),
(27, 1, 2, 1, 'Desert', 'desert.jpg');

DROP TABLE IF EXISTS `shop_parameters`;
CREATE TABLE `shop_parameters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rank` mediumint(8) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `units` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `values` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rank` (`rank`)
) ENGINE=MyISAM AUTO_INCREMENT=7 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `shop_parameters` VALUES
(1, 10, 1, 'Процесор', '', 'a:2:{i:1;s:23:\"Intel Pentium Dual Core\";i:2;s:10:\"Intel Atom\";}', 1),
(2, 6, 2, 'Экран', 'дюймов', 'i:1;', 1),
(3, 8, 1, 'Расширение монитора', '', 'a:1:{i:1;s:8:\"1366x768\";}', 1),
(4, 2, 3, 'Bluetooth', '', 'a:2:{i:1;s:8:\"есть\";i:2;s:6:\"нет\";}', 1),
(5, 1, 3, 'Wi-Fi', '', 'a:2:{i:1;s:8:\"Есть\";i:2;s:6:\"Нет\";}', 1),
(6, 9, 2, 'Вес', 'кг.', '0', 1);

DROP TABLE IF EXISTS `shop_products`;
CREATE TABLE `shop_products` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ИД',
  `n` int(10) unsigned NOT NULL COMMENT 'глобальная сортировка',
  `article` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'артикул',
  `special` tinyint(1) DEFAULT '0',
  `rating` decimal(2,1) unsigned NOT NULL,
  `market` tinyint(1) unsigned NOT NULL COMMENT 'яндекс маркет',
  `category` int(10) unsigned NOT NULL,
  `categories` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `brand` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `date` datetime DEFAULT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `price` int(10) unsigned NOT NULL,
  `price2` int(10) unsigned DEFAULT NULL,
  `similar` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `name1` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */,
  `text1` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `imgs` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `images` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `p1` int(10) unsigned NOT NULL,
  `p2` decimal(10,1) NOT NULL,
  `p3` int(10) unsigned NOT NULL,
  `p4` int(10) unsigned NOT NULL,
  `p5` int(10) unsigned NOT NULL,
  `p6` decimal(10,0) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `price` (`price`),
  KEY `category` (`category`),
  KEY `date` (`date`),
  KEY `special` (`special`),
  KEY `shop_brand` (`brand`),
  KEY `price_discount` (`price2`),
  KEY `display` (`display`),
  KEY `article` (`article`),
  KEY `p1` (`p1`),
  KEY `p2` (`p2`),
  KEY `p3` (`p3`),
  KEY `p4` (`p4`),
  KEY `p5` (`p5`),
  KEY `p6` (`p6`),
  KEY `n` (`n`)
) ENGINE=MyISAM AUTO_INCREMENT=22 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `shop_products` VALUES
(1, 6, '122345', 1, '0.0', 0, 13, '', '1', '2010-12-28 11:49:34', 1, 1223, 1234, '', 'Acer Aspire AS5755G-2634G50Mnks', '', '', '', '', 'Acer Aspire AS5755G-2634G50Mnks', 'Экран 15.6&quot;, 1366x768, LED / Intel Pentium Dual Core P6000 (1.86 ГГц) / RAM 2 ГБ / HDD 320 ГБ / ATI Radeon HD 545v, 512 МБ / DVD Super Multi / LAN / Wi-Fi / веб-камера / DOS / 2.4 кг Acer Aspire AS5755G-2634G50Mnks', '<p>Экран 15.6&quot;, 1366x768, LED / Intel Pentium Dual Core P6000 (1.86 ГГц) / RAM 2 ГБ / HDD 320 ГБ / ATI Radeon HD 545v, 512 МБ / DVD Super Multi / LAN / Wi-Fi / веб-камера / DOS / 2.4 кг<span id=&quot;copyinfo&quot;><br /></span></p>', '2.jpg', 'a:4:{i:1;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"22.jpg\";s:4:\"name\";s:7:\"rqwerqw\";s:7:\"display\";s:1:\"1\";}i:2;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"23.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}i:3;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"24.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}i:4;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"25.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 'a:4:{s:6:\"22.jpg\";a:2:{s:4:\"name\";s:7:\"rqwerqw\";s:7:\"display\";s:1:\"1\";}s:6:\"23.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"24.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"25.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 0, '11.0', 0, 0, 1, '2'),
(6, 1, '4564356', 1, '0.0', 0, 13, '', '1', '2010-12-28 12:10:48', 1, 538, 0, '', 'Asus K53BR', '', '', '', '', 'Asus K53BR', 'Asus K53BR (15,6&quot; HD(1366x768)/AMD DC E450/4Gb/500Gb/Radeon HD 7470, 1GB/DVD SM DL/Web-Cam 0.3Mp/Wi-Fi/BT/3xUSB/HDMI,VGA/CR3in1/DOS/6cell/2.6kg) Asus K53BR', '<p>Asus K53BR (15,6&quot; HD(1366x768)/AMD DC E450/4Gb/500Gb/Radeon HD 7470, 1GB/DVD SM DL/Web-Cam 0.3Mp/Wi-Fi/BT/3xUSB/HDMI,VGA/CR3in1/DOS/6cell/2.6kg)</p>', '31.jpg', 'a:4:{i:1;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"32.jpg\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"33.jpg\";s:7:\"display\";s:1:\"1\";}i:3;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"34.jpg\";s:7:\"display\";s:1:\"1\";}i:4;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"35.jpg\";s:7:\"display\";s:1:\"1\";}}', 'a:4:{s:6:\"32.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"33.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"34.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"35.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 0, '0.0', 0, 0, 0, '0'),
(7, 4, '435643', 1, '5.0', 1, 13, '', '1', '2010-12-28 16:10:33', 1, 404, 0, '', 'Acer Aspire 5250-E302G32Mikk', '', '', '', '', 'Acer Aspire 5250-E302G32Mikk', 'dfgadfg Acer Aspire 5250-E302G32Mikk', '<p>Acer Aspire 5250-E302G32Mikk/15.6&quot; HD WXGAG/AMD DC E-300 1.3GHz/2GB/320GB/AMD Radeon HD6310M/DVD SM/LAN/WiFi GN/CR 2in1/HDMI/Cam 0.3M/OS Linux/4400 mAh 6-cell/2.6 kg</p>', '1.jpg', 'a:2:{i:1;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"11.jpg\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"12.jpg\";s:7:\"display\";s:1:\"1\";}}', 'a:2:{s:6:\"11.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"12.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 0, '0.0', 0, 0, 0, '0'),
(8, 5, '456345', 1, '5.0', 0, 13, '', '2', '2011-02-25 16:38:46', 1, 905, 190, '', 'Asus N53SV', '', '', '', 'asus, n53sv, i7-2630qm, core, n53sv-sx633d, 1366x768', 'Asus N53SV', 'N53SV-SX633D Asus N53SV (15.6\'\' (1366x768) LED/Core i7-2630QM(2.0 GHz)/4Gb/500Gb/GeForce GT540M, 1Gb/DVD SM/LAN/Wi-Fi/BT/HDMI/Web-Cam/CR3in1/DOS/6cell/2.7kg) Asus N53SV', '<p>Asus N53SV (15.6\'\' (1366x768) LED/Core i7-2630QM(2.0 GHz)/4Gb/500Gb/GeForce GT540M, 1Gb/DVD SM/LAN/Wi-Fi/BT/HDMI/Web-Cam/CR3in1/DOS/6cell/2.7kg)</p>', '11.jpg', 'a:4:{i:1;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"12.jpg\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"13.jpg\";s:7:\"display\";s:1:\"1\";}i:3;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"14.jpg\";s:7:\"display\";s:1:\"1\";}i:4;a:3:{s:4:\"name\";s:0:\"\";s:4:\"file\";s:6:\"15.jpg\";s:7:\"display\";s:1:\"1\";}}', 'a:4:{s:6:\"12.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"13.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"14.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"15.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 0, '0.0', 0, 1, 1, '1'),
(9, 2, '3456456', 0, '5.0', 1, 13, '12,13', '4', '2011-02-25 16:39:35', 1, 0, 0, '', 'товар', '', '', '', '', 'Lenovo IdeaPad B570A', 'Lenovo IdeaPad B570A 15.6&quot; (1366x768) LED, глянцевый/Intel Core i5-2430M (2.4 ГГц) / RAM 4 ГБ / HDD 500 ГБ / nVidia GeForce 410M, 1 ГБ / DVD+/-RW / LAN / Wi-Fi / Bluetooth / веб-камера / DOS / 2.35 кг Lenovo IdeaPad B570A', '<p>Lenovo IdeaPad B570A 15.6&quot; (1366x768) LED, глянцевый/Intel Core i5-2430M (2.4 ГГц) / RAM 4 ГБ / HDD 500 ГБ / nVidia GeForce 410M, 1 ГБ / DVD+/-RW / LAN / Wi-Fi / Bluetooth / веб-камера / DOS / 2.35 кг</p>', '11.jpg', 'a:3:{i:1;a:3:{s:4:\"file\";s:6:\"12.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}i:2;a:3:{s:4:\"file\";s:6:\"13.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}i:3;a:3:{s:4:\"file\";s:6:\"14.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 'a:3:{s:6:\"12.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"13.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"14.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 0, '14.0', 1, 0, 0, '4'),
(10, 3, '34563456', 1, '2.5', 1, 13, '', '1', '2011-02-25 16:39:35', 1, 6373, 0, '1', 'Samsung Series', 'Samsung Series', '', '', '', 'Samsung Series 3', 'Samsung Series 3 15,6\'\' (1366x768)HD LED, матовый/Intel Core i3-2310M (2.1 ГГц)/RAM 3 ГБ/HDD 320 ГБ/nVidia GFce 520MX, 1 ГБ/DVD Super Multi/LAN/Wi-Fi/Bluetooth 3.0/веб-камера/DOS/2.45 кг/черный 628.00 Samsung Series 3', '<p>Samsung Series 3 15,6\'\' (1366x768)HD LED, матовый/Intel Core i3-2310M (2.1 ГГц)/RAM 3 ГБ/HDD 320 ГБ/nVidia GFce 520MX, 1 ГБ/DVD Super Multi/LAN/Wi-Fi/Bluetooth 3.0/веб-камера/DOS/2.45 кг/черный</p>', '11.jpg', 'a:3:{i:1;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"12.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}i:2;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"13.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}i:3;a:4:{s:4:\"temp\";s:0:\"\";s:4:\"file\";s:6:\"14.jpg\";s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 'a:3:{s:6:\"12.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"13.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}s:6:\"14.jpg\";a:2:{s:4:\"name\";s:0:\"\";s:7:\"display\";s:1:\"1\";}}', 1, '0.0', 1, 0, 1, '11');

DROP TABLE IF EXISTS `shop_products-categories`;
CREATE TABLE `shop_products-categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `child` int(10) unsigned NOT NULL,
  `parent` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `child` (`child`),
  KEY `parent` (`parent`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `shop_reviews`;
CREATE TABLE `shop_reviews` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` tinyint(3) unsigned NOT NULL,
  `rating` tinyint(1) unsigned NOT NULL,
  `product` int(10) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `email` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `display` (`display`),
  KEY `product` (`product`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=8 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `shop_reviews` VALUES
(1, 1, 4, 10, '2014-05-27 14:29:52', 'Дмитрий', 'ottofonf@gmail.com', '<p>первый отзыв о товаре<br />в две строчки</p>'),
(6, 0, 5, 9, '2015-04-12 15:46:05', 'Верстка и программирование', 'ottofonf@rambler.ru', '<p>вапывап</p>'),
(4, 0, 5, 9, '2015-04-12 15:35:17', 'ertyet', 'ottofonf@rambler.ru', '<p>ertyerty</p>'),
(5, 0, 5, 9, '2015-04-12 15:42:37', 'erter', 'ottofonf@rambler.ru', '<p>tert</p>'),
(7, 1, 5, 7, '2015-06-29 14:52:29', 'Дмитрий', 'ottofonf@gmail.com', '<p>отзыв о товаре</p>');

DROP TABLE IF EXISTS `slider`;
CREATE TABLE `slider` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `display` tinyint(3) unsigned NOT NULL,
  `rank` int(11) NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `slider` VALUES
(1, 1, 10, 'Пустыня', '', '<p>qwerty<br />dfeafsadf<br /><span style=\"line-height: 1.5;\">sadf&nbsp;</span></p>', 'desert.jpg'),
(2, 1, 8, 'Пингвины', '', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.&nbsp;</p>', 'penguins.jpg'),
(3, 1, 1, 'Коала', '', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'koala.jpg');

DROP TABLE IF EXISTS `subscribe_letters`;
CREATE TABLE `subscribe_letters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `subject` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `sender` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `sender_name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `subscribe_letters` VALUES
(1, '2013-12-11 14:33:27', 'Первая пробная рассылка', 'ottofonf@gmail.com', 'Дмитрий Смаль', 'текст первой рассылки\r\n<br />\r\nвот такой');

DROP TABLE IF EXISTS `subscribers`;
CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display` tinyint(3) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `email` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `surname` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `display` (`display`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `subscribers` VALUES
(1, 1, '2013-12-11 13:56:59', 'ottofonf@gmail.com', 'Дмитрий', 'Смаль');

DROP TABLE IF EXISTS `tests`;
CREATE TABLE `tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` smallint(5) unsigned NOT NULL DEFAULT '1',
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `shortdesc` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rank` (`rank`),
  KEY `display` (`display`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `tests` VALUES
(1, 100, 1, 1, 'Конкурс является методическим фестивалем авторских разработок по английскому языку.', '\"Teaching English\"', '<div style=\"line-height: 30px;\"><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\"><strong><span style=\"text-decoration: underline;\">На конкурс принимаются авторские методические материалы, такие как:</span></strong></span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #0000cd; font-family: \'Bookman Old Style\'; font-size: 19px;\"> &bull; </span><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Конспект урока;</span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #0000cd; font-family: \'Bookman Old Style\'; font-size: 19px;\"> &bull; </span><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Статья по проблеме преподавания английского языка;</span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #0000cd; font-family: \'Bookman Old Style\'; font-size: 19px;\"> &bull; </span><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Обобщение педагогического опыта по проблеме преподавания английского языка;</span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #0000cd; font-family: \'Bookman Old Style\'; font-size: 19px;\"> &bull; </span><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Презентация к уроку или мероприятию;</span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #0000cd; font-family: \'Bookman Old Style\'; font-size: 19px;\"> &bull; </span><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Рабочая программа по английскому языку;</span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #0000cd; font-family: \'Bookman Old Style\'; font-size: 19px;\"> &bull; </span><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Календарно-тематическое планирование по английскому языку;</span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #0000cd; font-family: \'Bookman Old Style\'; font-size: 19px;\"> &bull; </span><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Сценарий внеклассного мероприятия;</span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #0000cd; font-family: \'Bookman Old Style\'; font-size: 19px;\"> &bull; </span><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Элективный курс, программа;</span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #0000cd; font-family: \'Bookman Old Style\'; font-size: 19px;\"> &bull; </span><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Вебквест, глог, интерактивные материалы по проблеме преподавания английского языка;</span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #0000cd; font-family: \'Bookman Old Style\'; font-size: 19px;\"> &bull; </span><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Авторский персональный сайт учителя, используемый для преподавания английского языка;</span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #0000cd; font-family: \'Bookman Old Style\'; font-size: 19px;\"> &bull; </span><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">Авторский сайт творческих групп или методических объединений, используемый для преподавания </span></div>\r\n<div style=\"line-height: 29px;\"><span style=\"color: #000000; font-family: \'Bookman Old Style\'; font-size: 19px;\">английского языка;</span></div>', 'teaching-english', '\"Teaching English\"', 'преподавания, языка, по, английского, проблеме, материалы, для, авторский, принимаются, используемый, или, английскому, программа, сайт', 'На конкурс принимаются авторские методические материалы, такие как: Конспект урока; Статья по проблеме преподавания английского языка;', '0.png');

DROP TABLE IF EXISTS `tests_data`;
CREATE TABLE `tests_data` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test` int(10) unsigned NOT NULL,
  `date` datetime NOT NULL,
  `fio` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `address` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `workplace` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `comment` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `file` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

DROP TABLE IF EXISTS `user_fields`;
CREATE TABLE `user_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rank` int(11) NOT NULL,
  `display` tinyint(1) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL,
  `required` tinyint(1) unsigned NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `hint` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `values` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `user_fields` VALUES
(1, 10, 1, 1, 1, 'Имя Отчество', '', ''),
(2, 2, 1, 1, 1, 'Город', '', ''),
(3, 12, 1, 1, 1, 'Фамилия', '', ''),
(4, 1, 1, 1, 1, 'Учебное заведение', '', '');

DROP TABLE IF EXISTS `user_types`;
CREATE TABLE `user_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `access_admin` varchar(1000) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  `access_delete` tinyint(1) unsigned DEFAULT NULL,
  `access_ftp` tinyint(1) unsigned DEFAULT NULL,
  `access_editable` varchar(1000) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `ut_name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `user_types` VALUES
(1, 'a:23:{i:0;s:5:\"pages\";i:1;s:9:\"olympiads\";i:2;s:15:\"olympiads_tests\";i:3;s:20:\"olympiads_categories\";i:4;s:8:\"contests\";i:5;s:19:\"contests_categories\";i:6;s:12:\"publications\";i:7;s:5:\"tests\";i:8;s:9:\"languages\";i:9;s:8:\"feedback\";i:10;s:6:\"orders\";i:11;s:5:\"users\";i:12;s:10:\"user_types\";i:13;s:11:\"user_fields\";i:14;s:6:\"config\";i:15;s:16:\"letter_templates\";i:16;s:4:\"logs\";i:17;s:12:\"template_css\";i:18;s:15:\"template_images\";i:19;s:17:\"template_includes\";i:20;s:16:\"template_scripts\";i:21;s:6:\"backup\";i:22;s:7:\"restore\";}', 1, 1, 'a:9:{i:0;s:10:\"dictionary\";i:1;s:5:\"pages\";i:2;s:4:\"news\";i:3;s:13:\"shop_products\";i:4;s:15:\"shop_categories\";i:5;s:11:\"shop_brands\";i:6;s:12:\"shop_reviews\";i:7;s:11:\"user_fields\";i:8;s:16:\"order_deliveries\";}', 'Администраторы'),
(2, '', 0, 0, '', 'Пользователи');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ИД',
  `date` datetime NOT NULL COMMENT 'дата регистрации',
  `remind` datetime NOT NULL,
  `last_visit` datetime NOT NULL COMMENT 'время последней авторизации',
  `birthday` datetime NOT NULL,
  `remember_me` tinyint(1) unsigned NOT NULL COMMENT 'запомнить меня',
  `type` tinyint(1) unsigned DEFAULT NULL COMMENT 'группа пользователей',
  `email` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'логин',
  `hash` varchar(32) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'hash',
  `avatar` varchar(10) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'изображение',
  `fields` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL COMMENT 'динамические характеристики',
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`email`),
  KEY `type` (`type`),
  KEY `date` (`date`)
) ENGINE=MyISAM AUTO_INCREMENT=3 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */ PACK_KEYS=0 COMMENT='Пользователи';

INSERT INTO `users` VALUES
(1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2015-11-06 13:02:48', '0000-00-00 00:00:00', 1, 1, 'admin', 'bbccfd97fdd9dd272302336ae596423f', '', 'a:4:{i:3;a:1:{i:0;s:14:\"Дмитрий\";}i:1;a:1:{i:0;s:14:\"Украина\";}i:2;a:1:{i:0;s:1:\"1\";}i:4;a:1:{i:0;s:18:\"фрилансер\";}}'),
(2, '2010-11-25 20:57:04', '2015-11-13 11:53:46', '2016-01-28 17:30:55', '0000-00-00 00:00:00', 1, 1, 'bertino@mail.ru', '50e332506f5695880e223985b98e20ce', '', 'a:4:{i:3;a:1:{i:0;s:26:\"Администратор\";}i:1;a:1:{i:0;s:34:\"Администраторович\";}i:2;a:1:{i:0;s:18:\"Краснодар\";}i:4;a:1:{i:0;s:19:\"МБОУ СОШ 100\";}}');

