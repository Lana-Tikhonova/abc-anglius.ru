#SKD101|data_base|3|2017.04.18 06:31:52|7|1|1|5

DROP TABLE IF EXISTS `online_olympiads`;
CREATE TABLE `online_olympiads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category` int(11) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `rank` smallint(5) unsigned NOT NULL DEFAULT '1',
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `url` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `title` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `keywords` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `description` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `kl1` tinyint(1) unsigned DEFAULT '0',
  `kl2` tinyint(1) unsigned DEFAULT '0',
  `kl3` tinyint(1) unsigned DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `display` (`display`),
  KEY `rank` (`rank`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `online_olympiads` VALUES
(1, 1, 91, 1, 1, '', 'Тест', '', 'test', 'Тест', 'тест', 'Тест', 0, 0, 0);

DROP TABLE IF EXISTS `online_olympiads_categories`;
CREATE TABLE `online_olympiads_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rank` smallint(5) unsigned NOT NULL DEFAULT '1',
  `teacher` tinyint(1) unsigned NOT NULL,
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `name` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `price` int(10) unsigned NOT NULL DEFAULT '0',
  `price2` int(10) unsigned NOT NULL DEFAULT '0',
  `price3` int(10) unsigned NOT NULL DEFAULT '0',
  `date1` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date2` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `summarizing` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `text` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  `img` varchar(255) /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rank` (`rank`),
  KEY `display` (`display`)
) ENGINE=MyISAM AUTO_INCREMENT=2 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `online_olympiads_categories` VALUES
(1, 1, 0, 1, 'Педагоги', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '<p>В олимпиаде могут принять участие учащиеся 1 - 11 классов, студенты. Цель олимпиады: проверить знание лексики и грамматики английского языка, сформированность коммуникативной компетенции, развивать навыки чтения и перевода, создать основу для расширения базы знаний, формировать интерес к изучению английского языка. В олимпиаде содержится 10 заданий.</p>', '31.jpg');

DROP TABLE IF EXISTS `online_olympiads_tests`;
CREATE TABLE `online_olympiads_tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `olympiad` int(10) unsigned NOT NULL,
  `rank` smallint(5) unsigned NOT NULL DEFAULT '1',
  `display` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `klass` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `qa` text /*!40101 COLLATE utf8_unicode_ci */ NOT NULL,
  PRIMARY KEY (`id`),
  KEY `olympiad` (`olympiad`),
  KEY `rank` (`rank`),
  KEY `display` (`display`)
) ENGINE=MyISAM AUTO_INCREMENT=6 /*!40101 DEFAULT CHARSET=utf8 */ /*!40101 COLLATE=utf8_unicode_ci */;

INSERT INTO `online_olympiads_tests` VALUES
(1, 0, 1, 1, 0, ''),
(2, 0, 1, 1, 0, ''),
(3, 0, 1, 1, 0, ''),
(4, 0, 1, 1, 0, ''),
(5, 1, 1, 1, 0, 'a:2:{i:1;a:9:{s:1:\"q\";s:15:\"Как тест\";s:1:\"a\";s:1:\"2\";s:3:\"img\";s:54:\"https://anglius.ru/files/olympiads/10/img/p-test10.jpg\";s:5:\"audio\";s:0:\"\";s:5:\"video\";s:0:\"\";s:2:\"a1\";s:1:\"1\";s:2:\"a2\";s:1:\"2\";s:2:\"a3\";s:1:\"3\";s:2:\"a4\";s:1:\"4\";}i:2;a:9:{s:1:\"q\";s:31:\"Вопрос 2 тестовый\";s:1:\"a\";s:1:\"1\";s:3:\"img\";s:0:\"\";s:5:\"audio\";s:0:\"\";s:5:\"video\";s:0:\"\";s:2:\"a1\";s:1:\"6\";s:2:\"a2\";s:1:\"7\";s:2:\"a3\";s:1:\"8\";s:2:\"a4\";s:1:\"9\";}}');

